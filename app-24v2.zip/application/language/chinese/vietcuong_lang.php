<?php
$lang['tintucmoinhat']='新聞資訊';
$lang['doitac']='合作夥伴和客戶';
$lang['hotro']=' 在線支持';
$lang['luotruycap']='計數器';
$lang['sanphambanchay']= '產品中心';
$lang['sanphamnoibat']= '產品中心';
$lang['danhmuc']= '產品類別';
$lang['xemchitiet']= ' 具體...';
$lang['tintuckhac']= '其它';
$lang['tintuc']= '新聞資訊';
$lang['gia']= '';
$lang['lienhe']= '聯繫方式';
$lang['masp']= ' 產品型號 :';
$lang['timkiem']= ' 輸入搜索詞... ';
$lang['gioithieu']= ' 關於我們 ';
$lang['sanpham']= '產品中心';
$lang['chitietsanpham']= '關於我們';
$lang['motasanpham']= '產品描述 ';
$lang['binhluan']= 'Comment ';
$lang['spcungloai']= '產品展示:';
$lang['xuatxu']= 'Origin :';
$lang['tencty']= ' 越南 和偉達超聲波設備有限公司 :';
$lang['diachi']= '越南胡志明市新平郡第十五坊黄柏达路9号';
$lang['sodt']= ' 電話: （0084-08）6257  0088   傳真: （0084-08）6257  0099   郵箱:  yuxibing88@126.com';
$lang['xemthem']= ' See More ';
         
  
?>