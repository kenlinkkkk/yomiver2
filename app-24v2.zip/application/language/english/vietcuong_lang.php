<?php
$lang['tintucmoinhat']='Hot News';
$lang['doitac']='Partners';
$lang['hotro']=' Online Supporting';
$lang['luotruycap']=' Hits Online' ;
$lang['sanphambanchay']= ' Hot Products';
$lang['sanphamnoibat']= ' Special Products';
$lang['danhmuc']= ' Category';
$lang['timkiem']= ' Search';
$lang['tintuckhac']= ' Orther Articles';
$lang['xemchitiet']= ' Details';
$lang['tintuc']= ' News';
$lang['gia']= ' Price :';
$lang['lienhe']= ' Contact Us';
$lang['masp']= ' Code :';
$lang['gioithieu']= ' About Us ';
$lang['timkiem']= ' Search....';
$lang['sanpham']= ' Product ';
$lang['chitietsanpham']= ' Product\'s Details ';
$lang['motasanpham']= 'Product Description ';
$lang['binhluan']= 'Comment ';
$lang['spcungloai']= 'Familiar Products ';

$lang['xemthem']= ' See More ';

$lang['giatot']= 'Best Price'; 
$lang['tuyendung']= 'Career';    
$lang['hotro']= 'Support'; 
$lang['dangnhap']= 'Log In';    
$lang['dangky']= 'Register';  
$lang['home']= 'Home'; 

$lang['danhmucdichvu']= 'Services'; 
$lang['duantieubieu']= 'Typical Projects'; 

$lang['thongtin']= 'Infomation'; 
$lang['muahang']= 'Support'; 
$lang['hoptac']= 'Co-ordiration'; 
$lang['yeucau'] = 'Contact us if you have any questions';
$lang['diachi'] = 'L14-08B 14th Floor, Vincom Building - 72 Le Thanh Ton St, Ben Nghe Ward, District 1, HCMC ';
$lang['tomtatsanpham'] = '
 ******** <br>
 Thời gian bán hàng online  <br />
- Hotline : 0466534477 -  0129.909.0990 <br>
- Time : Monday to Sunday   <br />
- Address : 48A Ngo 1 Bui Xuong Trach, Khuong Trung, Thanh Xuan, Ha Noi<br />';        

$lang['tintuc'] = ' News';
$lang['trang'] = ' Page ';
$lang['chamsoc'] = ' Contact Us ';
$lang['tencongty']= 'D AND D JOINT STOCK COMPANY';
$lang['diachiemail']= 'E-mail address';  
$lang['nhanthongtin']= 'Enter your e-mail to receive our information'; 
$lang['mota']= 'Description'; 
$lang['muanhanh']= 'Buy';
 $lang['giohang']= 'Add Cart';    
$lang['soluong']= 'Quantity';
$lang['spbanchay']= 'Hot Products';
$lang['thoigian']= 'Online sale time';
$lang['ndthoigian']= '- Hotline : 0916.52.27.71 - 0911.69.96.69 <br>- Monday to Friday: from 08:30 to 17:00 - Saturday : from 8:30 am to 12:00. Sunday and Holidays: off <br>- Address: L14-08B 14th Floor, Vincom Building - 72 Le Thanh Ton St, Ben Nghe Ward, District 1, HCMC ';
$lang['quyenloi']= '<strong>Customer\'s rights :</strong>';
$lang['ndquyenloi']= '* Check products before leaving <br> * Contact the Warranty Office if your products have any problems during warranty time';
$lang['nhapthongtin']= 'Please provide your information for the best price';
$lang['guilienhe']= 'Send';
$lang['ten']= 'Name ';
$lang['noidung']= 'Content ';
$lang['emailcuaban']= 'Your mail ';
$lang['vietbinhluan']= 'Comment ';
$lang['tencuaban']= 'Your name ';

$lang['ketnoi']= 'Online';

$lang['dangkymail']= 'Thank you for your registration.  Your information will be extremely kept secret and you can cancel the registration anytime. ';
$lang['kodangkymail']= 'This email has just been registered to receive information from  www.ddcorporation.vn !';
$lang['vuotqua']= ' Chương trình chỉ dành cho khách hàng đăng ký nhận tin www.ddcorporation.vn lần đầu tiên !';
$lang['tintucmoi']= ' News';
$lang['xemthemduan']= ' All Projects ';
$lang['xemthemtintuc']= ' All News ';
$lang['xemnhieu']= ' Most Viewed ';
$lang['dichvu']= ' SERVICES ';
$lang['chonngonngu']= ' Language';


// admin


$lang['trangchu']= ' Home Page';
$lang['danhmuc']= ' Category';
$lang['sanpham']= ' Products';
$lang['danhmucbaiviet']= ' Articles Category';
$lang['baiviet']= ' Articles ';
$lang['quangcao']= ' Ads';
$lang['tintuc']= ' News';
$lang['cauhinh']= ' Config';

$lang['quantrong']= ' Important';
$lang['canhbao']= ' Warning';
$lang['matkhau']= ' Password';
$lang['thongtin']= ' Infomation';
$lang['chucnang']= ' MAIN NAVIGATION';

$lang['timkiem']= ' Search';
$lang['chucnang']= ' Function';
$lang['tendanhmuc']= ' Category Name';
$lang['danhmucsanpham']= ' Category Product';

$lang['tensanpham']= ' Product Name';
$lang['hinhanh']= ' Images';
$lang['danhsachsanpham']= ' Add Product';
$lang['themsanpham']= ' Product List';

$lang['danhmucviet']= 'Category Name';
$lang['danhmuc']= 'Category';
$lang['hinhanh']= 'Images';
$lang['thongtin']= 'Infomation';
$lang['tomtat']= 'SUMMARY ';
$lang['noidung']= 'CONTENT';

$lang['tencauhinh']= 'Config Name';
$lang['tennguoidung']= 'User Name';
$lang['tentaikhoan']= 'Account Name';
$lang['taikhoan']= 'Account';
$lang['themtaikhoan']= 'Add Account';
$lang['matkhau']= 'Password';
$lang['mail']= 'Mail';
$lang['tieudebaiviet']= 'Articles Title ';

$lang['ads_add']= 'Ads Add ';
$lang['add']= ' Add ';
$lang['dentrangchu']= ' Visit Website ';
$lang['chonngonngu'] = ' Select Languages';

$lang['cauhinhngonngu'] = ' Custom Languages';


$lang['danhsachdanhmuc'] = ' List Category ';
$lang['themdanhmuc'] = ' Add Category';

$lang['seo'] = ' S.E.O ( Search Engine Optimization ) Support ';

$lang['danhmucbaiviet'] = ' Articles Category ';
$lang['taodanhmucbaiviet'] = ' Add Articles Category';
$lang['suadanhmucbaiviet'] = ' Edit Articles Category';

$lang['baiviet'] = ' Articles List ';
$lang['taobaiviet'] = ' Add Articles ';
$lang['suabaiviet'] = '  Edit Articles ';

$lang['mienphi'] = 'Free';
$lang['mua'] = 'Buy';
$lang['sanphambanchay'] = 'Product Hot';
$lang['haisantuoisong'] = ' Sea Food';
$lang['monngonmoingay'] = ' Món Ngon Mỗi Ngày';
$lang['luachondanhmuc'] = ' Category Product';
$lang['hotrotructuyen'] = ' Support Online';
$lang['ghichu'] = ' Vui lòng nhập thông tin. Chúng tôi sẽ liên hệ với bạn trong thời gian sớm nhất.';
$lang['thongketruycap'] = ' Thống kế truy cập';
$lang['ngonngu'] = 'Languages ';

$lang['hoten'] = ' Full name  ';
$lang['diachi'] = 'Address ';
$lang['dienthoai'] = 'Phone ';
$lang['matkhau'] = 'Password ';
$lang['xacnhanmatkhau'] = 'Password Repeat ';
$lang['toidaxem'] = 'I have read and agreed  ';
$lang['quychehoatdong'] = 'operating regulations';
$lang['fanpage'] = 'Follow Us';
$lang['giagoc'] = 'Original Price :';
$lang['soluong'] = 'Quantity :';
?>
