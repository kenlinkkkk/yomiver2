<?php

class Admin_article_model extends CI_Model
{

    function __construct()
    {
        parent::__construct();

    }

    //Ham lay ra danh sach các tin trong bảng article
    function get_list_article()
    {
        $query = ("SELECT id_art, art.title, art_cate.name, art.status as art_stt, u.username, views, art.created_at, parent FROM article art INNER JOIN article_category art_cate ON art.category_id = art_cate.id INNER JOIN users u ON u.id = art.id_user ORDER BY id_art DESC");
        return $this->db->query($query);
    }

    function add_article_img($art_parent, $art_title, $art_url, $art_images, $art_status, $art_re, $art_hot, $art_date, $art_user, $art_views, $art_username)
    {
        $this->db->set('category_id', $art_parent);
        $this->db->set('title', $art_title);
        $this->db->set('article_url', $art_url);
        $this->db->set('images', $art_images);
        $this->db->set('status', $art_status);
        $this->db->set('check_1', $art_re);
        $this->db->set('check_2', $art_hot);
        $this->db->set('created_at', $art_date);
        $this->db->set('id_user', $art_user);
        $this->db->set('art_username', $art_username);
//        $this->db->set('likes', $art_likes);
        $this->db->set('views', $art_views);
//        $this->db->set('share', $art_shares);
        $this->db->insert('article');
        return $this->db->insert_id();
    }

    function add_article_video($art_parent, $art_title, $art_url, $art_images, $art_video, $art_status, $art_re, $art_hot, $art_date, $art_user, $art_views, $art_username)
    {
        $this->db->set('category_id', $art_parent);
        $this->db->set('title', $art_title);
        $this->db->set('article_url', $art_url);
        $this->db->set('images', $art_images);
        $this->db->set('video', $art_video);
//        $this->db->set('youtube', $art_youtube);
        $this->db->set('status', $art_status);
        $this->db->set('check_1', $art_re);
        $this->db->set('check_2', $art_hot);
        $this->db->set('created_at', $art_date);
        $this->db->set('id_user', $art_user);
        $this->db->set('art_username', $art_username);
//        $this->db->set('likes', $art_likes);
        $this->db->set('views', $art_views);
//        $this->db->set('share', $art_shares);
        $this->db->insert('article');
        return $this->db->insert_id();
    }

    function edit_article($art_id, $art_parent, $art_title, $art_summary, $art_url, $art_images, $art_video, $art_content, $art_status, $art_re, $art_hot, $art_date, $art_user, $art_views, $art_likes, $art_shares, $art_username)
    {
        $this->db->set('category_id', $art_parent);
        $this->db->set('title', $art_title);
        $this->db->set('summary', $art_summary);
        $this->db->set('article_url', $art_url);
        $this->db->set('images', $art_images);
        $this->db->set('video', $art_video);
//        $this->db->set('youtube', $art_youtube);
        $this->db->set('content', $art_content);
        $this->db->set('status', $art_status);
        $this->db->set('check_1', $art_re);
        $this->db->set('check_2', $art_hot);
        $this->db->set('created_at', $art_date);
        $this->db->set('id_user', $art_user);
        $this->db->set('art_username', $art_username);
//        $this->db->set('likes', $art_likes);
        $this->db->set('views', $art_views);
//        $this->db->set('share', $art_shares);
        $this->db->where('id_art', $art_id);
        $this->db->update('article');
        return $this->db->insert_id();
    }

    function edit_article_img($art_id, $art_parent, $art_title, $art_url, $art_images, $art_status, $art_re, $art_hot, $art_date, $art_user, $art_views, $art_username)
    {
        $this->db->set('category_id', $art_parent);
        $this->db->set('title', $art_title);
        $this->db->set('article_url', $art_url);
        $this->db->set('images', $art_images);
        $this->db->set('status', $art_status);
        $this->db->set('check_1', $art_re);
        $this->db->set('check_2', $art_hot);
        $this->db->set('created_at', $art_date);
        $this->db->set('id_user', $art_user);
        $this->db->set('art_username', $art_username);
//        $this->db->set('likes', $art_likes);
        $this->db->set('views', $art_views);
//        $this->db->set('share', $art_shares);
        $this->db->where('id_art', $art_id);
        $this->db->update('article');
        return $this->db->insert_id();
    }

    function edit_article_video($art_id, $art_parent, $art_title, $art_url, $art_images, $art_video, $art_status, $art_re, $art_hot, $art_date, $art_user, $art_views)
    {
        $this->db->set('category_id', $art_parent);
        $this->db->set('title', $art_title);
        $this->db->set('article_url', $art_url);
        $this->db->set('images', $art_images);
        $this->db->set('video', $art_video);
//        $this->db->set('youtube', $art_youtube);
        $this->db->set('status', $art_status);
        $this->db->set('check_1', $art_re);
        $this->db->set('check_2', $art_hot);
        $this->db->set('created_at', $art_date);
        $this->db->set('id_user', $art_user);
//        $this->db->set('likes', $art_likes);
        $this->db->set('views', $art_views);
//        $this->db->set('share', $art_shares);
        $this->db->where('id_art', $art_id);
        $this->db->update('article');
        return $this->db->insert_id();
    }


    function delete_article($art_id)
    {
        $this->db->where('id_art', $art_id);
        $this->db->delete('article');
    }

    function check_art_url($art_url)
    {
        $this->db->from('article');
        $this->db->where('article_url', $art_url);
        $query = $this->db->get();
        if ($query->num_rows() == 0) {
            return false;
        } else
            return $query->row();
    }

    function get_row_article($art_id)
    {
        $this->db->from('article');
        $this->db->where('id_art', $art_id);
        $query = $this->db->get();
        if ($query->num_rows() == 0) {
            return false;
        } else
            return $query->row();
    }

    // lấy danh sách các thư mục
    function get_all_article_cate($id)
    {
        $this->db->from('article_category');
        $this->db->where('parent', $id);
        return $this->db->get();
    }


}