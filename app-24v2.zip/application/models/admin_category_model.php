<?php

class Admin_category_model extends CI_Model
{

    function __construct()
    {
        parent::__construct();
    }

    //Ham lay ra danh sach Danh muc trong bang Category
    function get_list_category()
    {
        $this->db->from('article_category');
        return $this->db->get();
    }


    // thêm danh mục
    function add_category($cat_name, $cat_url, $cat_parent, $cat_summary, $cat_stt)
    {
        $this->db->set('name', $cat_name);
        $this->db->set('url', $cat_url);
        $this->db->set('parent', $cat_parent);
        $this->db->set('cate_summary', $cat_summary);
        $this->db->set('status', $cat_stt);
        $this->db->insert('article_category');
        return $this->db->insert_id();
    }

    // sửa danh mục
    function edit_category($cat_id, $cat_name, $cat_url, $cat_parent, $cat_summary, $cat_stt)
    {
        $this->db->set('name', $cat_name);
        $this->db->set('url', $cat_url);
        $this->db->set('parent', $cat_parent);
        $this->db->set('cate_summary', $cat_summary);
        $this->db->set('status', $cat_stt);
        $this->db->where('id', $cat_id);
        $this->db->update('article_category');
    }

    //Ham Xoa trong bang Category
    function delete_category($cat_id)
    {
        $this->db->where('id', $cat_id);
        $this->db->delete('article_category');
    }

    // kiểm tra đường dẫn
    function check_cat_url($cat_url)
    {
        $this->db->from('article_category');
        $this->db->where('url', $cat_url);
        $query = $this->db->get();
        if ($query->num_rows() == 0) {
            return false;
        } else
            return $query->row();
    }

    function get_row_category($cat_id)
    {
        $this->db->from('article_category');
        $this->db->where('id', $cat_id);
        $query = $this->db->get();
        if ($query->num_rows() == 0) {
            return false;
        } else
            return $query->row();
    }

    // lấy id danh mục
    function get_list_cate_parent()
    {
        $this->db->select('id');
        $this->db->from('article_category');
        return $this->db->get();
    }


}