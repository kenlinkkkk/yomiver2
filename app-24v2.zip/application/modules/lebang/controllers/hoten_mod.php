<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Hoten_mod extends MX_Controller
{

	function index()
	{
		echo 'Lebang_mod';	
	}
	function get()
	{
		return 'le trong bang';	
	}

}