<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
        <h1>
            Danh sách bình luận
        </h1>
        <ol class="breadcrumb">
            <li><a href="#"><i class="fa fa-dashboard"></i> Admin</a></li>
            <li class="active"> Bình luận</li>
        </ol>
    </section>

    <!-- Main content -->
    <section class="content">
        <div class="row">
            <div class="col-xs-12">
                <div class="box">
                    <div class="box-header">
                        <h3 class="box-title">Tất cả bình luận</h3>

                        <div class="box-tools">
                            <div class="input-group input-group-sm" style="width: 150px;">
                                <a href="comment/add/1" type="submit" class="btn btn-info pull-left">Thêm bình luận</a>
                            </div>

                        </div>

                    </div>

                    <!-- /.box-header -->
                    <div class="box-body">
                        <div id="example1_wrapper" class="dataTables_wrapper form-inline dt-bootstrap">
                            <table id="example" class="display" style="width:100%">
                                <thead>
                                <tr>
                                    <th>Mã</th>
                                    <th>Bình luận</th>
                                    <th>Bài viết</th>
                                    <th>Người đăng</th>
                                    <th>Trạng thái</th>
                                    <th>Thời gian</th>
                                    <th>Hành động</th>
                                </tr>
                                </thead>
                                <tbody>
                                <?php foreach ($data_all_comment->result() as $row) { ?>
                                    <tr>
                                        <td><?= $row->id; ?></td>
                                        <td><?= $row->cmt; ?></td>
                                        <td><?= $row->title; ?></td>
                                        <td><?= $row->username; ?></td>
                                        <td><? if ($row->status == 'on') {
                                                ?><i class="fa fa-toggle-on" aria-hidden="true"></i>
                                            <? } else {
                                                ?>
                                                <i class="fa fa-toggle-off" aria-hidden="true"></i>
                                            <? } ?>
                                        </td>
                                        <td><?= $row->c_time; ?></td>
                                        <td>
                                            <a href="./comment/edit/<?= $row->id; ?>"
                                               class="btn btn-xs btn-default"><i
                                                    class="fa fa-edit"></i></i> Sửa bình luận</a>
                                            <a href="./comment/delete/<?= $row->id; ?>"
                                               class="btn btn-xs btn-default"
                                               onclick="return confirm('Bạn có chắc chắn muốn xóa?')"
                                               data-button-type="delete"><i
                                                    class="fa fa-trash"></i> Xóa</a>
                                        </td>
                                    </tr>
                                <?php } ?>
                                </tbody>
                                <tfoot>
                                <tr>
                                    <th>Mã</th>
                                    <th>Bình luận</th>
                                    <th>Bài viết</th>
                                    <th>Người đăng</th>
                                    <th>Thời gian</th>
                                    <th>Hành động</th>
                                </tr>
                                </tfoot>
                            </table>
                        </div>
                    </div>
                    <!-- /.box-body -->
                </div>
                <!-- /.box -->
            </div>
        </div>
    </section>
    <!-- /.content -->
</div>
