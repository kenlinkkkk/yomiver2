	<div class="container" align="center">
        <h3> Vui lòng sử dụng 3G/4G để đăng ký dịch vụ!</h3>
    </div>