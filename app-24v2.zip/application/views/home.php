<div class="clip-banner swiper-container swiper-container-horizontal">
    <div class="swiper-wrapper" style="transform: translate3d(-10792px, 0px, 0px); transition-duration: 0ms;">

        <?
        $i = 0;
        foreach ($data_all_slide->result() as $row) { ?>
            <div class="swiper-slide swiper-slide-duplicate <? if ($i == 2) {
                echo 'swiper-slide-duplicate-prev';
            } else if ($i == 3) {
                echo 'swiper-slide-duplicate-active';
            } else if ($i == 4) {
                echo 'swiper-slide-duplicate-next';
            } ?>" data-swiper-slide-index="<?= $i; ?>">
                <div class="clip-banner-c">
                    <div class="img ratio16x9">
                        <a href="<?= $row->url; ?>" title="<?= $row->name; ?>"
                           target="_self" class="btn clip-btn-2 ga_event">
                            <img class="img-responsive height-mobile" src="<?= $row->image; ?>"
                                 alt="<?= $row->name; ?>">
                        </a>
                    </div>

                    <div class="shadow"></div>

                    <div class="info">
                        <h4><?= $row->name; ?></h4>

                        <div class="desc ddd is-truncated" style="word-wrap: break-word;">
                            <?= $row->summary; ?>
                        </div>

                        <div class="action-button">
                            <a href="<?= $row->url; ?>" title="<?= $row->name; ?>"
                               target="_self" class="btn clip-btn-2 ga_event" style="margin-right: 15px;">
                                <i class="clip-icon-play-3"></i>
                            </a>
                        </div>
                    </div>
                </div>
            </div>
            <? $i++;
        } ?>


        <?
        $i = 0;
        foreach ($data_all_slide->result() as $row) { ?>
            <div class="swiper-slide <? if ($i == 2) {
                echo 'swiper-slide-prev';
            } else if ($i == 3) {
                echo 'swiper-slide-active';
            } else if ($i == 4) {
                echo 'swiper-slide-next';
            } ?>" data-swiper-slide-index="<?= $i; ?>">
                <div class="clip-banner-c">
                    <div class="img ratio16x9">
                        <a href="<?= $row->url; ?>" title="<?= $row->name; ?>"
                           target="_self" class="btn clip-btn-2 ga_event">
                            <img class="img-responsive height-mobile" src="<?= $row->image; ?>"
                                 alt="<?= $row->name; ?>">
                        </a>
                    </div>

                    <div class="shadow"></div>

                    <div class="info">
                        <h4><?= $row->name; ?></h4>

                        <div class="desc ddd is-truncated" style="word-wrap: break-word;">
                            <?= $row->summary; ?>
                        </div>

                        <div class="action-button">
                            <a href="<?= $row->url; ?>" title="<?= $row->name; ?>"
                               target="_self" class="btn clip-btn-2 ga_event" style="margin-right: 15px;">
                                <i class="clip-icon-play-3"></i>
                            </a>
                        </div>
                    </div>
                </div>
            </div>
            <? $i++;
        } ?>
        <?
        $i = 0;
        foreach ($data_all_slide->result() as $row) { ?>
            <div class="swiper-slide swiper-slide-duplicate <? if ($i == 2) {
                echo 'swiper-slide-duplicate-prev';
            } else if ($i == 3) {
                echo 'swiper-slide-duplicate-active';
            } else if ($i == 4) {
                echo 'swiper-slide-duplicate-next';
            } ?>" data-swiper-slide-index="<?= $i; ?>">
                <div class="clip-banner-c">
                    <div class="img ratio16x9">
                        <a href="<?= $row->url; ?>" title="<?= $row->name; ?>"
                           target="_self" class="btn clip-btn-2 ga_event">
                            <img class="img-responsive" src="<?= $row->image; ?>"
                                 alt="<?= $row->name; ?>">
                        </a>
                    </div>

                    <div class="shadow"></div>

                    <div class="info">
                        <h4><?= $row->name; ?></h4>

                        <div class="desc ddd is-truncated" style="word-wrap: break-word;">
                            <?= $row->summary; ?>
                        </div>

                        <div class="action-button">
                            <a href="<?= $row->url; ?>" title="<?= $row->name; ?>"
                               target="_self" class="btn clip-btn-2 ga_event" style="margin-right: 15px;">
                                <i class="clip-icon-play-3"></i>
                            </a>
                        </div>
                    </div>
                </div>
            </div>
            <? $i++;
        } ?>

    </div>
    <!-- Add Pagination -->
    <div class="swiper-button-next"></div>
    <div class="swiper-button-prev"></div>
</div>

<div class="container-fluid" style="background:#2a2a2a">
    <div class="container" style="margin-top:30px">
        <div class="row" style="margin-top: -25px;">

            <!-- Giải trí -->
            <div class="col-md-12 colreponse">
                <div class="col-sm-12 colreponse">
                    <div class="col-xs-9 nopadding">
                        <p class="tieude"><a href="<?= base_url(); ?>video/giai-tri">Giải trí</a></p>
                    </div>
                    <div class="col-xs-3">
                        <div style="
    float: right;
    color: #cccccc;
    font-weight: bold;
    margin-top: 20px;
    font-size: 13px;
    width: 100px;
    padding: 3px;
    padding-left: 6px;
    padding-right: 7px;
    margin-right: 0px;
    z-index: 9999999;

">
                            <a href="<?= base_url() . 'video/giai-tri'; ?>">Xem tất cả <i
                                        class="glyphicon glyphicon-forward"
                                        style="font-size10px;float: right;color: #fff;"></i></a>
                        </div>
                    </div>
                </div>
                <div class="clearfix"></div>
                <div class="col-sm-8 nopadding">
                    <div class="col-sm-7 nopadding">
                        <? foreach ($data_article_doi_song_1->result() as $row) { ?>
                            <div class="col-sm-12 colreponse ">
                                <a href="<?= base_url() . 'video/' . $row->article_url; ?>">
                                    <img
                                            src="<?= $row->images; ?>" width="100%" style="max-height: 255px;">
                                </a>


                            </div>
                            <div class="col-sm-12 colreponse">
                                <p style="font-size: 15px;color: #fff;font-weight: bold;padding-top: 5px">
                                    <a href="<?= base_url() . 'video/' . $row->article_url; ?>"> <?= subTitle($row->title,20); ?></a>
                                </p>
                                <p style="color: orange;font-size: 10px;margin-top: -5px"><span
                                            class="glyphicon glyphicon-eye-open"></span><?= ' ' . $row->views; ?>
                                    &nbsp;&nbsp;
                                    <span
                                            class="glyphicon glyphicon-time"></span><?= ' ' . time2ago(strtotime($row->created_at)); ?>
                                </p></div>
                        <? } ?>
                    </div>
                    <div class="col-sm-5">
                        <? foreach ($data_article_doi_song_6->result() as $row) { ?>
                            <div class="row" style="margin-bottom: 5px">
                                <div class="col-xs-4 colds nopadding">
                                    <a href="<?= base_url() . 'video/' . $row->article_url; ?>"><img
                                                src="<?= $row->images; ?>" width="100%" style="max-height: 90px"></a>
                                </div>
                                <div class="col-xs-8 ">
                                    <p style="font-size: 14px;color: #ccc;font-weight: bold"><a
                                                href="<?= base_url() . 'video/' . $row->article_url; ?>"> <?= subTitle($row->title, 9); ?></a>
                                    </p>
                                    <p style="color: orange; font-size: 10px; margin-top: -10px;"><span
                                                class="glyphicon glyphicon-eye-open"></span><?= ' ' . $row->views; ?>
                                        &nbsp;&nbsp;
                                        <span class="glyphicon glyphicon-time"></span><?= ' ' . time2ago(strtotime($row->created_at)); ?>
                                    </p>

                                </div>
                            </div>
                        <? } ?>
                    </div>
                </div>
                <div class="col-sm-4 nopadding coltab">
                    <ul class="nav nav-tabs">
                        <li class="active" style="width:50%"><a data-toggle="tab" href="#home">VIDEO ĐỀ XUẤT</a></li>
                        <li style="width:50%"><a data-toggle="tab" href="#menu1">VIDEO MỚI NHẤT</a></li>
                    </ul>

                    <div class="tab-content" style="background: #1c2529">
                        <div id="home" class="tab-pane fade in active">
                            <?php foreach ($data_video_recommend->result() as $row) { ?>
                                <div class="row"
                                     style="padding-left: 0px;padding-right: 0px;margin-top: 5px;margin-left: 0px">
                                    <div class="col-sm-12 nopadding">
                                        <div class="col-sm-4 coldx"
                                             style="padding-right: 0px; padding-left: 2px;padding-top: 2px;">
                                            <a href="<?= base_url() . 'video/' . $row->article_url; ?>"><img
                                                        src="<?= $row->images; ?>" width="100%" style="max-height: 85px"
                                                        title="<?= $row->title; ?>"></a>
                                        </div>
                                        <div class="col-sm-8" style="padding-top: 2px;">
                                            <p style="font-size: 12px;color: #ccc;font-weight: bold"><a
                                                        href="<?= base_url() . 'video/' . $row->article_url; ?>"> <?= $row->title; ?></a>
                                            </p>
                                            <p style="color: orange; font-size: 10px; margin-top: -5px;"><span
                                                        class="glyphicon glyphicon-eye-open"></span><?= ' ' . $row->views; ?>
                                                &nbsp;&nbsp;
                                                <span
                                                        class="glyphicon glyphicon-time"></span><?= ' ' . time2ago(strtotime($row->created_at)); ?>
                                            </p>
                                        </div>
                                    </div>

                                </div>
                            <?php } ?>
                        </div>
                        <div id="menu1" class="tab-pane fade">
                            <?php foreach ($data_video_new->result() as $row) { ?>
                                <div class="row"
                                     style="padding-left: 0px;padding-right: 0px;margin-top: 5px;margin-left: 0px">
                                    <div class="col-sm-4 "
                                         style="padding-right: 0px;padding-left: 2px;padding-top: 2px;">
                                        <a href="<?= base_url() . 'video/' . $row->article_url; ?>"><img
                                                    src="<?= $row->images; ?>" width="100%" style="max-height: 80px"
                                                    title="<?= $row->title; ?>"></a>
                                    </div>
                                    <div class="col-sm-8" style="padding-top: 2px;">
                                        <p style="font-size: 12px;color: #ccc;font-weight: bold"><a
                                                    href="<?= base_url() . 'video/' . $row->article_url; ?>"> <?= $row->title; ?></a>
                                        </p>
                                        <p style="color: orange; font-size: 10px; margin-top: -5px;"><span
                                                    class="glyphicon glyphicon-eye-open"></span><?= ' ' . $row->views; ?>
                                            &nbsp;&nbsp;
                                            <span
                                                    class="glyphicon glyphicon-time"></span><?= ' ' . time2ago(strtotime($row->created_at)); ?>
                                        </p>
                                    </div>
                                </div>
                            <?php } ?>
                        </div>
                    </div>
                </div>
            </div>

            <!--  Thích -->
            <div class="col-xs-12 colreponse">
                <div class="col-sm-12 colreponse">
                    <div class="col-sm-3 col-xs-9 nopadding">
                        <p class="tieude"><a href="<?= base_url(); ?>#">Có thể bạn thích</a></p>
                    </div>

                </div>
                <!-- het test-->
                <div class="col-sm-12 col-xs-12 nocol ">
                    <div class="owl-carousel owl-theme">
                        <? foreach ($data_video_like->result() as $row) { ?>
                            <div class="item">
                                <a href="<?= base_url() . 'video/' . $row->article_url; ?>" class="thumbnail"> <img
                                            src="<?= $row->images; ?>"
                                            alt="<?= $row->title; ?>"></a>
                                <div class="mota1">
                                    <p class="mota2" style="color: blue;    margin-right: 20px;"><a
                                                href="<?= base_url() . 'video/' . $row->article_url; ?>"><font
                                                    color="#ccc"><?= subTitle($row->title, 7); ?></font> </a></p>
                                </div>
                                <div class="clearfix"></div>
                                <div class="col-xs-12 nopadding" style="font-size: 12px;">
                                    <p style="line-height: 8px;color:orange; float: left"><span
                                                class="glyphicon glyphicon-eye-open"></span><?= ' ' . $row->views; ?>
                                        &nbsp;&nbsp;
                                        <span
                                                class="glyphicon glyphicon-time"></span><?= ' ' . time2ago(strtotime($row->created_at)); ?>
                                    </p>
                                </div>
                            </div>
                        <? } ?>
                    </div>
                </div>

            </div>

            <!--  Làm đẹp-->
            <div class="col-xs-12 colreponse">
                <div class="col-sm-12 colreponse">
                    <div class="col-sm-3 col-xs-9 nopadding">
                        <p class="tieude"><a href="<?= base_url(); ?>video/lam-dep">Làm đẹp</a></p>
                    </div>
                    <div class="col-sm-9 col-xs-3">
                        <div style="
    float: right;
    color: #cccccc;
    font-weight: bold;
    margin-top: 20px;
    font-size: 13px;
    width: 100px;
    padding: 3px;
    padding-left: 6px;
    padding-right: 7px;
    margin-right: 0px;

">
                            <a href="<?= base_url() . 'video/lam-dep'; ?>">Xem tất cả <i
                                        class="glyphicon glyphicon-forward"
                                        style="font-size10px;float: right;color: #fff;"></i></a>

                        </div>
                    </div>

                </div>
                <!-- het test-->
                <div class="col-sm-12 col-xs-12 nocol">
                    <div class="owl-carousel owl-theme">
                        <? foreach ($data_article_lam_dep->result() as $row) { ?>
                            <div class="item">
                                <a href="<?= base_url() . 'video/' . $row->article_url; ?>" class="thumbnail"> <img
                                            src="<?= $row->images; ?>"
                                            alt="<?= $row->title; ?>"></a>
                                <div class="mota1">
                                    <p class="mota2" style="color: blue;    margin-right: 20px;"><a
                                                href="<?= base_url() . 'video/' . $row->article_url; ?>"><font
                                                    color="#ccc"><?= subTitle($row->title, 7); ?></font> </a></p>
                                </div>
                                <div class="clearfix"></div>
                                <div class="col-xs-12 nopadding" style="font-size: 12px;">
                                    <p style="line-height: 8px;color:orange; float: left"><span
                                                class="glyphicon glyphicon-eye-open"></span><?= ' ' . $row->views; ?>
                                        &nbsp;&nbsp;
                                        <span
                                                class="glyphicon glyphicon-time"></span><?= ' ' . time2ago(strtotime($row->created_at)); ?>
                                    </p>
                                </div>
                            </div>
                        <? } ?>
                    </div>
                </div>

                <div class="col-sm-12 col-xs-12 nocol">
                    <div class="owl-carousel owl-theme">
                        <? foreach ($data_article_lam_dep1->result() as $row) { ?>
                            <div class="item">
                                <a href="<?= base_url() . 'video/' . $row->article_url; ?>" class="thumbnail"> <img
                                            src="<?= $row->images; ?>"
                                            alt="<?= $row->title; ?>"></a>
                                <div class="mota1">
                                    <p class="mota2" style="color: blue;    margin-right: 20px;"><a
                                                href="<?= base_url() . 'video/' . $row->article_url; ?>"><font
                                                    color="#ccc"><?= subTitle($row->title, 7); ?></font> </a></p>
                                </div>
                                <div class="clearfix"></div>
                                <div class="col-xs-12 nopadding" style="font-size: 12px;">
                                    <p style="line-height: 8px;color:orange; float: left"><span
                                                class="glyphicon glyphicon-eye-open"></span><?= ' ' . $row->views; ?>
                                        &nbsp;&nbsp;
                                        <span
                                                class="glyphicon glyphicon-time"></span><?= ' ' . time2ago(strtotime($row->created_at)); ?>
                                    </p>
                                </div>
                            </div>
                        <? } ?>
                    </div>
                </div>

            </div>

            <!--  Người đẹp-->
            <div class="col-xs-12 colreponse">
                <div class="col-sm-12 colreponse">
                    <div class="col-sm-3 col-xs-9 nopadding">
                        <p class="tieude"><a href="<?= base_url(); ?>video/nguoi-dep">Đẹp +</a></p>
                    </div>
                    <div class="col-sm-9 col-xs-3">
                        <div style="
    float: right;
    color: #cccccc;
    font-weight: bold;
    margin-top: 20px;
    font-size: 13px;
    width: 100px;
    padding: 3px;
    padding-left: 6px;
    padding-right: 7px;
    margin-right: 0px;

">
                            <a href="<?= base_url() . 'video/nguoi-dep'; ?>">Xem tất cả <i
                                        class="glyphicon glyphicon-forward"
                                        style="font-size10px;float: right;color: #fff;"></i></a>

                        </div>
                    </div>

                </div>
                <!-- het test-->
                <div class="col-sm-12 col-xs-12 nocol">
                    <div class="owl-carousel owl-theme">
                        <? foreach ($data_article_nguoi_dep->result() as $row) { ?>
                            <div class="item">
                                <a href="<?= base_url() . 'video/' . $row->article_url; ?>" class="thumbnail"> <img
                                            src="<?= $row->images; ?>"
                                            alt="<?= $row->title; ?>"></a>
                                <div class="mota1">
                                    <p class="mota2" style="color: blue;    margin-right: 20px;"><a
                                                href="<?= base_url() . 'video/' . $row->article_url; ?>"><font
                                                    color="#ccc"><?= subTitle($row->title, 7); ?></font> </a></p>
                                </div>
                                <div class="clearfix"></div>
                                <div class="col-xs-12 nopadding" style="font-size: 12px;">
                                    <p style="line-height: 8px;color:orange; float: left"><span
                                                class="glyphicon glyphicon-eye-open"></span><?= ' ' . $row->views; ?>
                                        &nbsp;&nbsp;
                                        <span
                                                class="glyphicon glyphicon-time"></span><?= ' ' . time2ago(strtotime($row->created_at)); ?>
                                    </p>
                                </div>
                            </div>
                        <? } ?>
                    </div>
                </div>

                <div class="col-sm-12 col-xs-12 nocol">
                    <div class="owl-carousel owl-theme">
                        <? foreach ($data_article_nguoi_dep1->result() as $row) { ?>
                            <div class="item">
                                <a href="<?= base_url() . 'video/' . $row->article_url; ?>" class="thumbnail"> <img
                                            src="<?= $row->images; ?>"
                                            alt="<?= $row->title; ?>"></a>
                                <div class="mota1">
                                    <p class="mota2" style="color: blue;    margin-right: 20px;"><a
                                                href="<?= base_url() . 'video/' . $row->article_url; ?>"><font
                                                    color="#ccc"><?= subTitle($row->title, 7); ?></font> </a></p>
                                </div>
                                <div class="clearfix"></div>
                                <div class="col-xs-12 nopadding" style="font-size: 12px;">
                                    <p style="line-height: 8px;color:orange; float: left"><span
                                                class="glyphicon glyphicon-eye-open"></span><?= ' ' . $row->views; ?>
                                        &nbsp;&nbsp;
                                        <span
                                                class="glyphicon glyphicon-time"></span><?= ' ' . time2ago(strtotime($row->created_at)); ?>
                                    </p>
                                </div>
                            </div>
                        <? } ?>
                    </div>
                </div>
            </div>



            <!-- Đời sống -->
            <div class="col-md-12 colreponse ">
                <div class="col-sm-12 colreponse ">
                    <div class="col-sm-3 col-xs-9 nopadding">
                        <p class="tieude"><a href="<?= base_url(); ?>video/doi-song">Đời sống</a></p>
                    </div>
                    <div class="col-sm-9 col-xs-3 ">
                        <div style="
    float: right;
    color: #cccccc;
    font-weight: bold;
    margin-top: 20px;
    font-size: 13px;
    width: 100px;
    padding: 3px;
    padding-left: 6px;
    padding-right: 7px;
    margin-right: 0px;

">
                            <a href="<?= base_url() . 'video/doi-song'; ?>">Xem tất cả <i
                                        class="glyphicon glyphicon-forward"
                                        style="font-size10px;float: right;color: #fff;"></i></a>

                        </div>
                    </div>

                </div>
                <div class="com-md-12 col-xs-12 colreponse ">
                    <div class="bao_videohot ">

                        <div class="col-sm-5 colreponse nopadding " style="padding-right:0px">
                            <? foreach ($data_article_giai_tri_1->result() as $row) { ?>
                                <div class="boxvideo1 gt2">

                                    <a class="videoout" href="<?= base_url() . 'video/' . $row->article_url; ?>">
                                        <img src="<?= $row->images; ?>"
                                             title="<?= $row->title; ?>" alt="<?= $row->title; ?>">

                                    </a>
                                </div>
                                <div class="mota3">
                                    <p class="mota2"
                                       style="color: #ccc;margin-right: 20px;"><a
                                                href="<?= base_url() . 'video/' . $row->article_url; ?>"><?= subTitle($row->title,21); ?></a>
                                    </p>
                                </div>
                                <div class="clearfix"></div>
                                <div class="col-xs-12 nopadding" style="font-size: 12px;">
                                    <p style="line-height: 8px;color:orange"><span
                                                class="glyphicon glyphicon-eye-open"></span><?= ' ' . $row->views; ?>
                                        <span
                                                class="glyphicon glyphicon-time"></span><?= ' ' . time2ago(strtotime($row->created_at)); ?>
                                    </p>
                                </div>
                            <? } ?>
                        </div>
                        <div class="col-sm-7 colreponse" style="padding-right:0px">
                            <?
                            foreach ($data_article_giai_tri_6->result() as $row) { ?>
                                <div class="col-sm-4 col-xs-6" style="padding-right: 2px; padding-left: 2px">
                                    <div class="boxvideo1 gt">
                                        <a class="videoout"
                                           href="<?= base_url() . 'video/' . $row->article_url; ?>"><img
                                                    src="<?= $row->images; ?>"
                                                    title="<?= $row->title; ?>" alt="<?= $row->title; ?>">
                                        </a>
                                    </div>
                                    <div class="mota3">
                                        <p class="mota2"
                                           style="color: #ccc;    margin-right: 20px;"><a
                                                    href="<?= base_url() . 'video/' . $row->article_url; ?>"><?= subTitle($row->title, 7); ?></a>
                                        </p>
                                    </div>
                                    <div class="clearfix"></div>
                                    <div class="col-xs-12 nopadding" style="font-size: 12px;">
                                        <p style="line-height: 8px;color:orange; float: left"><span
                                                    class="glyphicon glyphicon-eye-open"></span><?= ' ' . $row->views; ?>
                                            &nbsp;&nbsp;
                                            <span
                                                    class="glyphicon glyphicon-time"></span><?= ' ' . time2ago(strtotime($row->created_at)); ?>
                                        </p>
                                    </div>
                                </div>
                                <? $i++;
                            } ?>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Ảnh hài -->
            <div class="col-xs-12 colreponse">
                <div class="col-sm-12 colreponse">
                    <div class="col-sm-3 col-xs-9 nopadding">
                        <p class="tieude"><a href="<?= base_url(); ?>anh/anh-hai">Ảnh hài</a></p>
                    </div>
                    <div class="col-sm-9 col-xs-3">
                        <div style="
    float: right;
    color: #cccccc;
    font-weight: bold;
    margin-top: 20px;
    font-size: 13px;
    width: 100px;
    padding: 3px;
    padding-left: 6px;
    padding-right: 7px;
    margin-right: 0px;

">
                            <a href="<?= base_url() . 'anh/anh-hai'; ?>">Xem tất cả <i
                                        class="glyphicon glyphicon-forward"
                                        style="font-size10px;float: right;color: #fff;"></i></a>

                        </div>
                    </div>

                </div>
                <!-- het test-->
                <div class="col-sm-12 col-xs-12 nocol">
                    <div class="owl-carousel owl-theme">
                        <? foreach ($data_article_anh_hai->result() as $row) { ?>
                            <div class="item">
                                <a href="<?= base_url() . 'anh/' . $row->article_url; ?>" class="thumbnail"> <img
                                            src="<?= $row->images; ?>"
                                            alt="<?= $row->title; ?>"></a>
                                <div class="mota1">
                                    <p class="mota2" style="color: blue;    margin-right: 20px;"><a
                                                href="<?= base_url() . 'anh/' . $row->article_url; ?>"><font
                                                    color="#ccc"><?= subTitle($row->title, 7); ?></font> </a></p>
                                </div>
                                <div class="clearfix"></div>
                                <div class="col-xs-12 nopadding" style="font-size: 12px;">
                                    <p style="line-height: 8px;color:orange; float: left"><span
                                                class="glyphicon glyphicon-eye-open"></span><?= ' ' . $row->views; ?>
                                        &nbsp;&nbsp;
                                        <span
                                                class="glyphicon glyphicon-time"></span><?= ' ' . time2ago(strtotime($row->created_at)); ?>
                                    </p>
                                </div>
                            </div>
                        <? } ?>
                    </div>
                </div>
                <div class="col-sm-12 col-xs-12 nocol">
                    <div class="owl-carousel owl-theme">
                        <? foreach ($data_article_anh_hai1->result() as $row) { ?>
                            <div class="item">
                                <a href="<?= base_url() . 'anh/' . $row->article_url; ?>" class="thumbnail"> <img
                                            src="<?= $row->images; ?>"
                                            alt="<?= $row->title; ?>"></a>
                                <div class="mota1">
                                    <p class="mota2" style="color: blue;    margin-right: 20px;"><a
                                                href="<?= base_url() . 'anh/' . $row->article_url; ?>"><font
                                                    color="#ccc"><?= subTitle($row->title, 7); ?></font> </a></p>
                                </div>
                                <div class="clearfix"></div>
                                <div class="col-xs-12 nopadding" style="font-size: 12px;">
                                    <p style="line-height: 8px;color:orange; float: left"><span
                                                class="glyphicon glyphicon-eye-open"></span><?= ' ' . $row->views; ?>
                                        &nbsp;&nbsp;
                                        <span
                                                class="glyphicon glyphicon-time"></span><?= ' ' . time2ago(strtotime($row->created_at)); ?>
                                    </p>
                                </div>
                            </div>
                        <? } ?>
                    </div>
                </div>
            </div>

            <!-- Ảnh độc -->
            <div class="col-xs-12 colreponse ">
                <div class="col-sm-12 colreponse">
                    <div class="col-sm-3 col-xs-9 nopadding">
                        <p class="tieude"><a href="<?= base_url(); ?>anh/anh-doc">Ảnh độc</a></p>
                    </div>
                    <div class="col-sm-9 col-xs-3">
                        <div style="
    float: right;
    color: #cccccc;
    font-weight: bold;
    margin-top: 20px;
    font-size: 13px;
    width: 100px;
    padding: 3px;
    padding-left: 6px;
    padding-right: 7px;
    margin-right: 0px;

">
                            <a href="<?= base_url() . 'anh/anh-doc'; ?>">Xem tất cả <i
                                        class="glyphicon glyphicon-forward"
                                        style="font-size10px;float: right;color: #fff;"></i></a>

                        </div>
                    </div>

                </div>
                <!-- het test-->
                <div class="col-sm-12 col-xs-12 nocol colc">
                    <div class="owl-carousel owl-theme">
                        <? foreach ($data_article_anh_doc->result() as $row) { ?>
                            <div class="item">
                                <a href="<?= base_url() . 'anh/' . $row->article_url; ?>" class="thumbnail"> <img
                                            src="<?= $row->images; ?>"
                                            alt="<?= $row->title; ?>"></a>
                                <div class="mota1">
                                    <p class="mota2" style="color: blue;    margin-right: 20px;"><a
                                                href="<?= base_url() . 'anh/' . $row->article_url; ?>"><font
                                                    color="#ccc"><?= subTitle($row->title, 7); ?></font> </a></p>
                                </div>
                                <div class="clearfix"></div>
                                <div class="col-xs-12 nopadding" style="font-size: 12px;">
                                    <p style="line-height: 8px;color:orange; float: left"><span
                                                class="glyphicon glyphicon-eye-open"></span><?= ' ' . $row->views; ?>
                                        &nbsp;&nbsp;
                                        <span
                                                class="glyphicon glyphicon-time"></span><?= ' ' . time2ago(strtotime($row->created_at)); ?>
                                    </p>
                                </div>
                            </div>
                        <? } ?>

                    </div>
                </div>

                <div class="col-sm-12 col-xs-12 nocol colc">
                    <div class="owl-carousel owl-theme">
                        <? foreach ($data_article_anh_doc1->result() as $row) { ?>
                            <div class="item">
                                <a href="<?= base_url() . 'anh/' . $row->article_url; ?>" class="thumbnail"> <img
                                            src="<?= $row->images; ?>"
                                            alt="<?= $row->title; ?>"></a>
                                <div class="mota1">
                                    <p class="mota2" style="color: blue;    margin-right: 20px;"><a
                                                href="<?= base_url() . 'anh/' . $row->article_url; ?>"><font
                                                    color="#ccc"><?= subTitle($row->title, 7); ?></font> </a></p>
                                </div>
                                <div class="clearfix"></div>
                                <div class="col-xs-12 nopadding" style="font-size: 12px;">
                                    <p style="line-height: 8px;color:orange; float: left"><span
                                                class="glyphicon glyphicon-eye-open"></span><?= ' ' . $row->views; ?>
                                        &nbsp;&nbsp;
                                        <span
                                                class="glyphicon glyphicon-time"></span><?= ' ' . time2ago(strtotime($row->created_at)); ?>
                                    </p>
                                </div>
                            </div>
                        <? } ?>

                    </div>
                </div>

            </div>

            <!-- Hài hước -->
            <div class="col-xs-12 colreponse">
                <div class="col-sm-12 colreponse">
                    <div class="col-sm-3 col-xs-9 nopadding">
                        <p class="tieude"><a href="<?= base_url(); ?>video/hai-huoc">Hài hước</a></p>
                    </div>
                    <div class="col-sm-9 col-xs-3 ">
                        <div style="
    float: right;
    color: #cccccc;
    font-weight: bold;
    margin-top: 20px;
    font-size: 13px;
    width: 100px;
    padding: 3px;
    padding-left: 6px;
    padding-right: 7px;
    margin-right: 0px;

">
                            <a href="<?= base_url() . 'video/hai-huoc'; ?>">Xem tất cả <i
                                        class="glyphicon glyphicon-forward"
                                        style="font-size10px;float: right;color: #fff;"></i></a>

                        </div>
                    </div>

                </div>
                <!-- het test-->
                <div class="col-sm-12 col-xs-12 nocol">
                    <div class="owl-carousel owl-theme">
                        <? foreach ($data_article_hai_huoc->result() as $row) { ?>
                            <div class="item">
                                <a href="<?= base_url() . 'video/' . $row->article_url; ?>" class="thumbnail"> <img
                                            src="<?= $row->images; ?>"
                                            alt="<?= $row->title; ?>"></a>
                                <div class="mota1">
                                    <p class="mota2" style="color: blue;    margin-right: 20px;"><a
                                                href="<?= base_url() . 'video/' . $row->article_url; ?>"><font
                                                    color="#ccc"><?= subTitle($row->title, 7); ?></font> </a></p>
                                </div>
                                <div class="clearfix"></div>
                                <div class="col-xs-12 nopadding" style="font-size: 12px;">
                                    <p style="line-height: 8px;color:orange; float: left"><span
                                                class="glyphicon glyphicon-eye-open"></span><?= ' ' . $row->views; ?>
                                        &nbsp;&nbsp;
                                        <span
                                                class="glyphicon glyphicon-time"></span><?= ' ' . time2ago(strtotime($row->created_at)); ?>
                                    </p>
                                </div>
                            </div>
                        <? } ?>
                    </div>
                </div>

                <div class="col-sm-12 col-xs-12 nocol">
                    <div class="owl-carousel owl-theme">
                        <? foreach ($data_article_hai_huoc1->result() as $row) { ?>
                            <div class="item">
                                <a href="<?= base_url() . 'video/' . $row->article_url; ?>" class="thumbnail"> <img
                                            src="<?= $row->images; ?>"
                                            alt="<?= $row->title; ?>"></a>
                                <div class="mota1">
                                    <p class="mota2" style="color: blue;    margin-right: 20px;"><a
                                                href="<?= base_url() . 'video/' . $row->article_url; ?>"><font
                                                    color="#ccc"><?= subTitle($row->title, 7); ?></font> </a></p>
                                </div>
                                <div class="clearfix"></div>
                                <div class="col-xs-12 nopadding" style="font-size: 12px;">
                                    <p style="line-height: 8px;color:orange; float: left"><span
                                                class="glyphicon glyphicon-eye-open"></span><?= ' ' . $row->views; ?>
                                        &nbsp;&nbsp;
                                        <span
                                                class="glyphicon glyphicon-time"></span><?= ' ' . time2ago(strtotime($row->created_at)); ?>
                                    </p>
                                </div>
                            </div>
                        <? } ?>
                    </div>
                </div>

            </div>

            <!-- Phim -->
            <div class="col-xs-12 colphim colreponse">
                <div class="col-sm-12 colreponse">
                    <div class="col-sm-3 col-xs-9 nopadding">
                        <p class="tieude"><a href="<?= base_url(); ?>phim">Phim hay</a></p>
                    </div>
                    <div class="col-sm-9 col-xs-3">
                        <div style="
    float: right;
    color: #cccccc;
    font-weight: bold;
    margin-top: 20px;
    font-size: 13px;
    width: 100px;
    padding: 3px;
    padding-left: 6px;
    padding-right: 7px;
    margin-right: 0px;

">
                            Xem tất cả <i class="glyphicon glyphicon-forward"
                                          style="font-size10px;float: right;color: #fff;padding-top: 3px"></i>
                        </div>
                    </div>

                </div>
                <!-- het test-->
                <div class="col-sm-12 col-xs-12">
                    <div class="owl-carousel owl-theme">
                        <?php foreach ($data_article_movie->result() as $row) { ?>
                            <div class="item" style="color: black">
                                <div class="boxvideo4">
                                    <a class="videoout4" href="<?= base_url() . 'phim/' . $row->article_url; ?>">
                                        <img src="<?= $row->images; ?>">

                                        <div class="titlebox_videotop">
                                            <p class="tieude1"><?= subTitle($row->title, 5); ?></p>
                                            <div class="lt2">
                                                <font color="orange">
                                                    Lượt xem: <?= $row->views; ?></span>
                                                </font>
                                            </div>
                                        </div>
                                    </a>
                                </div>
                            </div>
                        <?php } ?>
                    </div>
                </div>
            </div>
            <!-- test-->
            <div class="clearfix"></div>
            <br/>
        </div>
    </div>
</div>