<?php
/**
 * Created by PhpStorm.
 * User: Truong Minh Duong
 * Date: 31/10/2018
 * Time: 4:31 CH
 */

?>

<div class="container" style="margin-top:30px">
    <div class="col-xs-12" style="margin-top: 10px;">
        <p class="tieude" style="color:black">Hướng dẫn sử dụng</p>
        <div class="col-xs-12">

            <p><strong>I. Đ&Ocirc;́I TƯỢNG :</strong></p>

            <ul>
                <li>Tất cả c&aacute;c thu&ecirc; bao MobiFone hoạt động 02 chiều tr&ecirc;n mạng.</li>
            </ul>

            <p><strong>II. ĐI&Ecirc;̀U KI&Ecirc;̣N SỬ DỤNG DỊCH VỤ:</strong></p>

            <ul>
                <li>Thu&ecirc; bao sử dụng điện thoại c&oacute; hỗ trợ Real player, hỗ trợ EDGE/3G v&agrave; tương th&iacute;ch với c&aacute;c nền tảng Java, Brew, Symbian, Windows Mobile, iOS, BlackBerry v&agrave; Android.</li>
            </ul>

            <p><strong>III. C&Aacute;C ƯU Đ&Atilde;I KHI SỬ DỤNG DỊCH VỤ</strong></p>

            <ul>
                <li>Bạn được miễn cước thu&ecirc; bao 1 ng&agrave;y cho lần đăng k&yacute; đầu ti&ecirc;n</li>
                <li>H&agrave;ng ng&agrave;y, bạn được miễn ph&iacute; 15 phút xem nội dung dịch vụ video/ảnh của Xem Li&ecirc;̀n</li>
                <li>Bạn được miễn ho&agrave;n to&agrave;n cước 3G/ GPRS khi sử dụng dịch vụ</li>
                <li>Bạn được mi&ecirc;̃n phí Tải/Tặng 5 n&ocirc;̣i dung.</li>
            </ul>

            <p><strong>IV. CÁCH THỨC ĐĂNG KÝ DỊCH VỤ</strong></p>

            <ul>
                <li>Để đăng k&yacute;, kh&aacute;ch h&agrave;ng truy cập wapstite http://xemlien.vn hoặc vào ứng dụng Xemlien, từ thanh Menu của dịch vụ, v&agrave;o phần Đăng ký để đăng k&yacute; t&agrave;i khoản, sau đ&oacute; v&agrave;o phần Cá nh&acirc;n để đăng k&yacute; g&oacute;i dịch vụ bạn muốn d&ugrave;ng. Muốn hủy g&oacute;i dịch vụ đ&atilde; đăng k&yacute;, bạn click v&agrave;o g&oacute;i dịch vụ đ&oacute; v&agrave; nhấn Hủy</li>
            </ul>

            <p>C&aacute;ch thức đăng k&yacute; qua SMS</p>

            <table class="table-bordered table" style="color: black;">
                <tbody>
                <tr>
                    <td>
                        <p style="text-align: center;"><strong>STT</strong></p>

                        <p style="text-align: center;">&nbsp;</p>
                    </td>
                    <td>
                        <p style="text-align: center;"><strong>T&ecirc;n g&oacute;i</strong></p>
                    </td>
                    <td>
                        <p style="text-align: center;"><strong>C&uacute; ph&aacute;p đăng k&yacute;</strong></p>
                    </td>
                    <td>
                        <p style="text-align: center;"><strong>Gi&aacute; cước</strong></p>
                    </td>
                </tr>
                <tr>
                    <td>
                        <p>1</p>
                    </td>
                    <td>
                        <p>G&oacute;i Ng&agrave;y</p>
                    </td>
                    <td>
                        <p><strong>DK XEM</strong> gửi <strong>9365</strong></p>
                    </td>
                    <td>
                        <p>2000đ/ng&agrave;y</p>
                    </td>
                </tr>
                <tr>
                    <td>
                        <p>2</p>
                    </td>
                    <td>
                        <p>G&oacute;i Tuần</p>
                    </td>
                    <td>
                        <p><strong>DK XEM7</strong> gửi <strong>9365</strong></p>
                    </td>
                    <td>
                        <p>10000đ/ng&agrave;y</p>
                    </td>
                </tr>
                <tr>
                    <td>
                        <p>3</p>
                    </td>
                    <td>
                        <p>G&oacute;i Tranh t&agrave;i showbiz</p>
                    </td>
                    <td>
                        <p><strong>DK TS</strong> gửi <strong>9365</strong></p>
                    </td>
                    <td>
                        <p>2000đ/ng&agrave;y. Miễn ph&iacute; 1 ng&agrave;y đầu ti&ecirc;n đối với thu&ecirc; bao đăng k&yacute; lần đầu. Tự động gia hạn.</p>
                    </td>
                </tr>
                <tr>
                    <td>
                        <p>4</p>
                    </td>
                    <td>
                        <p>Hướng dẫn sử dụng dịch vụ</p>
                    </td>
                    <td>
                        <p><strong>HD</strong> gửi <strong>9365</strong></p>
                    </td>
                    <td>
                        <p>&nbsp;</p>
                    </td>
                </tr>
                <tr>
                    <td>
                        <p>5</p>
                    </td>
                    <td>
                        <p>Lấy lại mật khẩu wap</p>
                    </td>
                    <td>
                        <p><strong>MK</strong> gửi <strong>9365</strong></p>
                    </td>
                    <td>
                        <p>&nbsp;</p>
                    </td>
                </tr>
                <tr>
                    <td>
                        <p>6</p>
                    </td>
                    <td>
                        <p>Ki&ecirc;m tra dịch vụ đang sử dụng</p>
                    </td>
                    <td>
                        <p><strong>KT</strong> gửi<strong> 9365</strong></p>
                    </td>
                    <td>
                        <p>&nbsp;</p>
                    </td>
                </tr>
                </tbody>
            </table>

            <p><strong>Cách thức đăng ký qua Web/Wap</strong></p>

            <ul>
                <li>Truy cập wapsite http://xemlien.vn</li>
                <li>Hệ thống tự động nhận diện số thu&ecirc; bao nếu truy cập qua GPRS/EDGE/3G. N&ecirc;́u truy c&acirc;̣p bằng wifi thì y&ecirc;u c&acirc;̀u đăng ký, đăng nh&acirc;̣p và xác thực OTP l&acirc;̀n đ&acirc;̀u ti&ecirc;n.</li>
                <li>Sau khi đ&atilde; đăng nhập th&igrave; v&agrave;o phần T&agrave;i khoản tr&ecirc;n thanh Menu, chọn mục G&oacute;i cước sau đ&oacute; click v&agrave;o g&oacute;i cước Ng&agrave;y/Tuần.</li>
                <li>Ấn n&uacute;t Đăng k&yacute;, h&ecirc;̣ th&ocirc;́ng sẽ hi&ecirc;̣n pop-up hướng d&acirc;̃n soạn tin nhắn đăng ký gói cước qua SMS.</li>
            </ul>

            <p><strong>Cách thức đăng ký qua Ứng dụng</strong></p>

            <ul>
                <li>Tải ứng dụng &ldquo;Xem liền&rdquo; từ Appstore hoặc Google play t&ugrave;y theo d&ograve;ng m&aacute;y sử dụng.</li>
                <li>Hệ thống tự động nhận diện số thu&ecirc; bao nếu truy cập qua GPRS/EDGE/3G. N&ecirc;́u truy c&acirc;̣p bằng wifi thì y&ecirc;u c&acirc;̀u đăng ký, đăng nh&acirc;̣p và xác thực OTP l&acirc;̀n đ&acirc;̀u ti&ecirc;n.</li>
                <li>Sau khi đ&atilde; đăng nhập th&igrave; v&agrave;o phần T&agrave;i khoản tr&ecirc;n thanh Menu, chọn mục G&oacute;i cước sau đ&oacute; click v&agrave;o g&oacute;i cước Ng&agrave;y/Tuần.</li>
                <li>Ấn n&uacute;t đăng k&yacute;, h&ecirc;̣ th&ocirc;́ng sẽ hi&ecirc;̣n pop-up hướng d&acirc;̃n soạn tin nhắn đăng ký gói cước qua SMS.</li>
            </ul>

            <p><strong>Thời hạn sử dụng v&agrave; gi&aacute; cước được quy định như sau:</strong></p>

            <ul>
                <li>G&oacute;i dịch vụ sử dụng theo Ng&agrave;y</li>
            </ul>

            <p>Đăng k&yacute; g&oacute;i dịch vụ sử dụng theo Ng&agrave;y, kh&aacute;ch h&agrave;ng được miễn ph&iacute; xem, tải, tặng kh&ocirc;ng giới hạn c&aacute;c nội dung video clip, ảnh do dịch vụ cung cấp trong 24 giờ t&iacute;nh từ thời điểm đăng k&yacute;.</p>

            <p>Gi&aacute; cước của g&oacute;i dịch vụ sử dụng theo Ng&agrave;y l&agrave; 2.000 đồng/ng&agrave;y.</p>

            <ul>
                <li>G&oacute;i dịch vụ sử dụng theo Tuần</li>
            </ul>

            <p>Đăng k&yacute; g&oacute;i dịch vụ sử dụng theo Tuần, kh&aacute;ch h&agrave;ng được miễn ph&iacute; xem, tải, tặng kh&ocirc;ng giới hạn c&aacute;c nội dung video clip, ảnh do dịch vụ cung cấp trong 07 ng&agrave;y (168 giờ) t&iacute;nh từ thời điểm đăng k&yacute;.</p>

            <p>Gi&aacute; cước của g&oacute;i dịch vụ sử dụng theo Tuần l&agrave; 10.000 đồng/tuần.</p>

            <p>Dịch vụ tự động hủy trong trường hợp kh&ocirc;ng trừ được cước li&ecirc;n tục trong thời gian 30 ng&agrave;y.</p>

            <p><strong>C&aacute;c t&iacute;nh năng kh&aacute;c:</strong></p>

            <ul>
                <li><strong>Tìm ki&ecirc;́m: </strong>Cung cấp cho kh&aacute;ch h&agrave;ng c&ocirc;ng cụ tìm ki&ecirc;́m th&ocirc;ng tin m&ocirc;̣t cách nhanh chóng.</li>
                <li><strong>T&iacute;nh năng b&igrave;nh luận, Like, chia sẻ </strong>cho người d&ugrave;ng th&ocirc;ng qua t&agrave;i khoản Facebook.</li>
                <li><strong>T&iacute;nh năng tự động cập nhật ứng dụn</strong>g khi c&oacute; phi&ecirc;n bản mới.</li>
            </ul>

            <p><strong>&nbsp;V. HƯỚNG D&Acirc;̃N SỬ DỤNG DỊCH VỤ</strong></p>

            <p><strong>C&aacute;ch thức sử dụng qua wapsite:</strong></p>

            <p>Bước 1: Từ điện thoại di động, truy cập http://xemlien.vn/</p>

            <p>Bước 2: Bạn được xem ảnh, đọc truy&ecirc;̣n và 15 phút nội dung clip miễn ph&iacute;, hết 15 phút nội dung miễn ph&iacute; chuyển sang bước 3</p>

            <p>Bước 3: Đăng nhập để sử dụng dịch vụ, nếu bạn chưa c&oacute; t&agrave;i khoản chuyển sang bước 4, nếu bạn đ&atilde; c&oacute; t&agrave;i khoản chuyển sang bước 5.</p>

            <p>Bước 4: Đăng k&yacute; t&agrave;i khoản v&agrave; chọn g&oacute;i cước theo hướng dẫn</p>

            <p>Bước 5: Sau khi đăng nhập th&agrave;nh c&ocirc;ng, bạn có th&ecirc;̉ sử dụng các chức năng của trang.&nbsp;&nbsp;</p>

            <p><strong>* Đăng k&yacute; g&oacute;i bạn c&oacute; thể</strong></p>

            <ul>
                <li>Xem tất cả c&aacute;c nội dung của dịch vụ qua k&ecirc;nh wapsite</li>
                <li>B&igrave;nh luận, chia sẻ nội dung dịch vụ y&ecirc;u th&iacute;ch tới bạn b&egrave;, người th&acirc;n</li>
            </ul>

            <p>C&aacute;ch thức sử dụng qua Ứng dụng:</p>

            <p>Sau khi tải v&agrave; c&agrave;i đặt ứng dụng th&agrave;nh c&ocirc;ng, bạn khởi động ứng dụng v&agrave; bật kết nối GPRS/EDGE/3G hoặc wifi v&agrave; thực hiện theo c&aacute;c bước sau:</p>

            <p>Bước 1: Bạn được xem ảnh, đọc truy&ecirc;̣n và 15 phút nội dung clip miễn ph&iacute;, hết 15 phút nội dung miễn ph&iacute; chuyển sang bước 2</p>

            <p>Bước 2: Hệ thống y&ecirc;u cầu bạn đăng đăng nhập, nếu bạn chưa c&oacute; t&agrave;i khoản chuyển sang bước 3, nếu bạn đ&atilde; c&oacute; t&agrave;i khoản chuyển sang bước 4.</p>

            <p>Bước 3: Đăng k&yacute; t&agrave;i khoản v&agrave; chọn g&oacute;i cước theo hướng dẫn</p>

            <p>Bước 4: Đăng nhập v&agrave; tiếp tục sử dụng dịch vụ</p>

            <p>Một số t&iacute;nh năng ch&iacute;nh cung cấp qua ứng dụng:</p>

            <ul>
                <li>Xem tất cả c&aacute;c nội dung của dịch vụ</li>
                <li>Tải/tặng 5 nội dung miễn ph&iacute;/ng&agrave;y.</li>
                <li>Từ nội dung thứ 6 mức ph&iacute; từ 1.000- 15.000 đồng/1 nội dung</li>
                <li>N&ecirc;́u bạn đã đăng ký gói thì sẽ được tải/tặng mi&ecirc;̃n phí kh&ocirc;ng giới hạn s&ocirc;́ lượng.</li>
                <li>B&igrave;nh luận, chia sẻ nội dung y&ecirc;u th&iacute;ch tới bạn b&egrave;, người th&acirc;n.</li>
            </ul>

        </div>
    </div>
</div>