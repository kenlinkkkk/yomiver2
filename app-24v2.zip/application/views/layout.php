<? foreach (getallheaders() as $name => $value) {
    if ('MSISDN' == $name) {
        $msisdn = $value;
        $this->session->set_userdata("phone", $msisdn);
    }
} ?>

<!DOCTYPE html>
<html lang="en">
<head>
    <title><?= $this->config->item('title'); ?></title>
    <meta property="og:title" content="<?= $this->config->item('title'); ?>"/>
    <meta property="og:url" content="<?= $this->config->item('og_url'); ?>"/>
    <meta property="og:image" content="<?= $this->config->item('og_image'); ?>"/>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <script src="<?= base_url(); ?>js/jquery.min.js"></script>
    <script src="<?= base_url(); ?>js/popper.min.js"></script>
    <link rel="shortcut icon" href="<?= base_url(); ?>images/favicon.ico"/>

    <!-- font awesome -->
    <link href="<?= base_url(); ?>css/font-awesome.css">
    <! Bootstrap -->
    <!-- Latest compiled and minified CSS -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css"
          integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">

    <!-- Optional theme -->
    <!--    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap-theme.min.css" integrity="sha384-rHyoN1iRsVXV4nD0JutlnGaslCJuC7uwjduW9SVrLvRYooPp2bWYgmgJQIXwl/Sp" crossorigin="anonymous">-->
    <!-- Latest compiled and minified JavaScript -->
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"
            integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa"
            crossorigin="anonymous"></script>

    <!-- silde -->
    <link rel="stylesheet" href="<?= base_url(); ?>css/owl.carousel.min.css">
    <link rel="stylesheet" href="<?= base_url(); ?>css/owl.theme.default.min.css">
    <script src="<?= base_url(); ?>js/owl.carousel.min.js"></script>
    <script src="http://mobiclip.vn/assets/6c002df5/js/swiper.min.js?v=1531905211"></script>
    <script src="http://mobiclip.vn/assets/6c002df5/js/jquery.nanoscroller.min.js?v=1531905211"></script>
    <script src="http://mobiclip.vn/assets/6c002df5/js/jquery.scrollbar.min.js?v=1531905211"></script>

    <link rel="stylesheet" href="http://mobiclip.vn/assets/6c002df5/css/swiper.min.css?v=1531905211">
    <link rel="stylesheet" href="http://mobiclip.vn/assets/6c002df5/css/style.min.css?v=1531905211">
    <link rel="stylesheet" href="<?= base_url(); ?>css/styles.css">
    <link rel="stylesheet" href="<?= base_url(); ?>css/style.css">
    <link rel="stylesheet" href="https://fontawesome.com/v4.7.0/assets/font-awesome/css/font-awesome.css">
    <style>


        .owl-theme .owl-nav [class*=owl-]:hover {
            /*background: #869791;*/
            color: #FFF;
            text-decoration: none;
        }

        @media (min-width: 1000px) {
            .owl-prev {
                position: absolute;
                left: -15px;
            }

            .owl-next {
                position: absolute;
                right: -15px;

            }

            .owl-theme .owl-nav [class*=owl-] {
                background: none;
                opacity: 0.5;
                height: 194px;


            }
        }

        @media (max-width: 1000px) {
            .owl-prev {
                position: absolute;
                left: -32px;
                top: 25px
            }

            .owl-next {
                position: absolute;
                right: -32px;
                top: 25px

            }

            .nocol {
                padding-left: 0px;
                padding-right: 0px;
            }

            .owl-theme .owl-nav [class*=owl-] {
                background: none;
                opacity: 0.5;
                height: 168px;

            }
        }

        /*.owl-theme .owl-nav [class*=owl-] {*/
        /*background: black;*/
        /*}*/
        .owl-theme .owl-dots .owl-dot.active span {
            background: #e09422;
            width: 30px;
            transition: all 0.5s;
        }

        .owl-theme .owl-dots .owl-dot span {
            background: #e09422;
        }

        @media only screen and (min-width: 900px) {
            .item img {
                width: 100%;
                height: 190px;
            }

            .searchrespone {
                display: none;
            }

        }

    </style>


</head>

<body style="background: #e9ebee">

<div class="container-fluid " style="height: 50px;background: black" id="menulogo">
    <div class="container" style="margin-top: 6px;">
        <div class="row" style="padding: 5px">
            <div class="col-sm-2" id="banner1">
                <a href="<?= base_url(); ?>"><img src="<?= base_url(); ?>images/logo.png"
                                                  class="img-CTKM-Wap wow fadeInUp" alt=""
                                                  style="width:80%;visibility: visible; animation-name: fadeInUp;"></a>
            </div>

            <div class="col-sm-5 " style="  margin-top: -3px;
        margin-left: -50px;">
                <div id="imaginary_container">
                    <form method="post" action="<?= base_url(); ?>search">
                        <div class="input-group stylish-input-group">
                            <input type="text" class="form-control" placeholder="Nhập từ khóa tìm kiếm" name="search">
                            <span class="input-group-addon">
                        <button type="submit" name="submitsearch">
                            <span class="glyphicon glyphicon-search"></span>
                        </button>
                    </span>

                        </div>
                    </form>

                </div>
            </div>
            <div class="col-sm-5">

                <div class="col-sm-6 nopadding">
                    <ul style="padding-top: 6px;font-size: 13px;font-weight:bold">
                        <li style="list-style: none"><a href="<?= base_url(); ?>huong-dan"> HƯỚNG DẪN SỬ DỤNG</a></li>
                    </ul>
                </div>
                <div class="col-sm-6">
                    <ul class="nav navbar-nav navbar-right" style="font-size: 13px">

                        <? if (empty($idu)) { ?>
                            <li class="dk nav-mobi"><a data-toggle="modal" data-target="#myModal2"> Đăng nhập </a></li>
                            <li class="dk nav-mobi"><a data-toggle="modal" data-target="#myModal3">Đăng ký</a></li>
                        <? } else { ?>
                            <li class="dk nav-mobi"><a href="<?= base_url(); ?>member">Trang cá nhân</a></li>
                            <li class="dk nav-mobi"><a href="<?= base_url(); ?>logout">Đăng xuất</a></li>
                        <? } ?>
                    </ul>

                </div>
            </div>

        </div>
    </div>
</div>


<nav class="navbar navbar-inverse" style="margin-bottom: 0px;">
    <div class="container">
        <div class="navbar-header">
            <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">

                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
            </button>
            <a href="<?= base_url(); ?>" class="navbar-toggle"
               style="left:22%;margin-left: -20px;font-size: 12px;"><img
                        src="<?= base_url(); ?>images/logo.png" width="120px;" style="margin-top: -5px;"></a>
        </div>
        <div class="collapse navbar-collapse" id="myNavbar">
            <ul class="nav navbar-nav">
                <div class="mobile-nav" style="text-transform: capitalize;

    font-weight: bold;">
                    <? if (!empty($msisdn)) { ?>
                        <li style="padding-top: 7px; color: white">
                            <?= 'Chào bạn: ' . substr($msisdn, 0, 7) . "xxxx"; ?>
                        </li>
                    <? } ?>
                    <li style="padding-top: 7px;"><a href="<?= base_url(); ?>"><span
                                    class="glyphicon glyphicon-home" aria-hidden="true"></span>&nbsp;&nbsp;&nbsp;&nbsp;Trang
                            chủ</a></li>
                    <li style="padding-top: 12px;"><a href="<?= base_url(); ?>dang-ky-dich-vu"><span
                                    class="glyphicon glyphicon-gift" aria-hidden="true"></span>&nbsp;&nbsp;&nbsp;&nbsp;Đăng
                            ký gói cước</a></li>
                    <li style="padding-top: 12px; text-transform: uppercase; padding-bottom: 5px;"><a
                                href="<?= base_url(); ?>">KÊNH CHỌN
                            LỌC</a></li>
                </div>
                <li class=""><a href="<?= base_url(); ?>" style="text-transform: capitalize;"><span
                                class="glyphicon glyphicon-home mobile-nav-hidden" aria-hidden="true"></span></a></li>
                <li><a href="<?= base_url(); ?>video/doi-song" style="text-transform: capitalize;"><span
                                class="glyphicon glyphicon-music" aria-hidden="true"></span>&nbsp;&nbsp;&nbsp;&nbsp;Đời
                        sống</a></li>
                <li><a href="<?= base_url(); ?>video/giai-tri" style="text-transform: capitalize;"><span
                                class="glyphicon glyphicon-headphones" aria-hidden="true"></span>&nbsp;&nbsp;&nbsp;&nbsp;Giải
                        trí</a></li>
                <li><a href="<?= base_url(); ?>video/hai-huoc" style="text-transform: capitalize;"><span
                                class="glyphicon glyphicon-sunglasses" aria-hidden="true"></span>&nbsp;&nbsp;&nbsp;&nbsp;Hài
                        hước</a></li>
                <li><a href="<?= base_url(); ?>video/lam-dep" style="text-transform: capitalize;"><span
                                class="glyphicon glyphicon-heart" aria-hidden="true"></span>&nbsp;&nbsp;&nbsp;&nbsp;Làm
                        đẹp</a></li>
                <li><a href="<?= base_url(); ?>video/nguoi-dep" style="text-transform: capitalize;"><span
                                class="glyphicon glyphicon-camera" aria-hidden="true"></span>&nbsp;&nbsp;&nbsp;&nbsp;Đẹp
                        +</a></li>
                <li><a href="<?= base_url(); ?>anh/anh-hai" style="text-transform: capitalize;"><span
                                class="glyphicon glyphicon-picture" aria-hidden="true"></span>&nbsp;&nbsp;&nbsp;&nbsp;Ảnh
                        hài</a></li>
                <li><a href="<?= base_url(); ?>anh/anh-doc" style="text-transform: capitalize;"><span
                                class="glyphicon glyphicon-picture" aria-hidden="true"></span>&nbsp;&nbsp;&nbsp;&nbsp;Ảnh
                        độc</a></li>
<li><a href="<?= base_url(); ?>phim" style="text-transform: capitalize;"><span
                                class="glyphicon glyphicon-film" aria-hidden="true"></span>&nbsp;&nbsp;&nbsp;&nbsp;Phim</a></li>
                <!--                <li><a href="--><? //= base_url(); ?><!--phim">Phim</a></li>-->
                <? if (!empty($idu)) { ?>
                    <li><a href="#" data-toggle="modal" data-target="#myModal">Đăng bài</a></li>
                <? } ?>
                <div class="mobile-nav" style="text-transform: uppercase; font-weight: bold;">
                    <li style="padding-top: 7px; text-transform: uppercase; padding-bottom: 5px;"><a
                                href="<?= base_url(); ?>">THÔNG TIN DỊCH
                            VỤ</a></li>
                </div>
                <li><a href="<?= base_url(); ?>tranh-tai-showbiz" style="text-transform: capitalize;"><span
                                class="glyphicon glyphicon-star" aria-hidden="true"></span>&nbsp;&nbsp;&nbsp;&nbsp;Tranh
                        tài showbiz</a></li>
                <div class="mobile-nav" style="text-transform: uppercase;

    font-weight: bold;">
                    <li style="padding-top: 7px; padding-bottom: 10px; padding-left: 6px;"><a
                                href="<?= base_url(); ?>huong-dan" style="text-transform: capitalize;"><span
                                    class="glyphicon glyphicon-list" aria-hidden="true"></span>&nbsp;&nbsp;&nbsp;&nbsp;Hướng
                            dẫn sử dụng</a></li>
                    <!--                    <li style="padding-top: 10px;"><a data-toggle="modal" data-target="#myModal2">Đăng nhập</a></li>-->
                    <!--                    <li style="padding-top: 10px;"><a data-toggle="modal" data-target="#myModal3">Đăng ký</a></li>-->
                </div>

            </ul>

            <div class="col-sm-3 col-md-3 searchrespone">
                <form class="navbar-form" role="search" method="post" action="<?= base_url(); ?>search">
                    <div class="input-group">
                        <input type="text" class="form-control" placeholder="Search" name="search" style="height: 29px">
                        <div class="input-group-btn">
                            <button class="btn btn-default" type="submit" name="submitsearch"><i class="glyphicon glyphicon-search"></i>
                            </button>
                        </div>
                    </div>
                </form>
            </div>

        </div>
    </div>
</nav>


<?= $main; ?>

</body>
<!-- Footer -->
<!-- Modal -->
<div class="modal fade" id="myModal" role="dialog" style="z-index: 99999;">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">

                <p style="text-align: center;color:rgba(244,67,54,1);font-size: 17px;font-weight: bold">ĐĂNG
                    BÀI LÊN XEMLIEN.VN</p>
                <button type="button" class="close" data-dismiss="modal">&times;</button>

            </div>
            <div class="modal-body">

                <div class="td4">
                    <b><i class="fa fa-pencil"></i> Chia sẻ nhiều hơn với cộng đồng nào!!!</b>

                </div>
                <form method="post" action="">
                    <div class="form-group">
                        <label> Tên bài viết</label>
                        <input type="text" class="form-control" id="art_title" name="art_title"
                               required
                               placeholder="Nhập tên bài viết">
                    </div>
                    <div class="form-group">
                        <label>Danh mục</label>
                        <select class="form-control" id="art_parent" name="art_parent">
                            <? foreach ($data_all_cate->result() as $item) { ?>
                                <option value="<?= $item->id; ?>"><?= $item->name; ?></option>
                            <? } ?>
                        </select>
                    </div>


                    <div class="form-group">
                        <label>Hình ảnh </label>

                        <div class="form-group">
                            <input type="file" name="picture">
                        </div>
                    </div>


                    <div class="form-group">
                        <label>Video </label>
                        <div class="form-group">
                            <input type="file" name="fileVideo">
                        </div>
                    </div>


                    <button type="submit" class="btn btn-success" name="submit_post_mem"
                            id="submit_post_mem">Gửi bài viết
                    </button>
                </form>
            </div>
        </div>
    </div>
</div>
<!-- Dang nhap -->

<div class="modal fade" id="myModal2" role="dialog" style="z-index: 99999;">
    <div class="modal-dialog">

        <!-- Modal content-->
        <div class="modal-content">
            <div class="modal-header" style="background: cornflowerblue;">
                <button type="button" class="close" data-dismiss="modal">&times;</button>
                <h4 class="modal-title" style="text-align:center;color: #fff;">Đăng nhập</h4>
            </div>
            <div class="modal-body">
                <form method="post" action="">
                    <div class="form-group">
                        <label> Tên tài khoản</label>
                        <input type="text" class="form-control" id="log_name" name="log_name" tabindex="1"
                               required
                               value=""
                               placeholder="Nhập tên tài khoản">
                    </div>

                    <div class="form-group">
                        <label> Mật khẩu</label>
                        <input type="password" class="form-control" id="log_pass" name="log_pass"
                               tabindex="1"
                               required
                               value=""
                               placeholder="Nhập mật khẩu">
                    </div>
                    <div class="clearfix"></div>
                    <br/>
                    <button type="submit" class="btn btn-success" name="submit_login">Đăng nhập</button>
                </form>
                <!--                            <p>- Hoặc -</p>-->
                <!--                            <p class="text-center btn-tk" style="background:#3B5998; padding:10px;">-->
                <!--                                <a href="https://www.facebook.com/dialog/oauth?client_id=307396673188050&redirect_uri=http://v2.xemlien.vn/login/facebook"><i-->
                <!--                                            class="fa fa-facebook-square"></i> Đăng nhập bằng Facebook</a></p>-->

            </div>
            <div class="modal-footer">

                <button type="button" class="btn btn-danger" data-dismiss="modal">Thoát</button>
            </div>
        </div>
    </div>
</div>
<!-- Đăng ký -->
<div class="modal fade" id="myModal3" role="dialog" style="z-index: 99999;">
    <div class="modal-dialog">
        <!-- Modal content-->
        <div class="modal-content">
            <div class="modal-header" style="background: cornflowerblue;">
                <button type="button" class="close" data-dismiss="modal">&times;</button>
                <h4 class="modal-title" style="text-align:center;color: #fff;">Đăng ký tài khoản</h4>
            </div>
            <div class="modal-body">
                <form method="post" action="">
                    <div class="form-group">
                        <label> Tên tài khoản</label>
                        <input type="text" class="form-control" id="reg_name" name="reg_name"
                               required
                               placeholder="Nhập tên tài khoản">
                    </div>

                    <div class="form-group">
                        <label> Mật khẩu</label>
                        <input type="password" class="form-control" id="reg_pass" name="reg_pass"
                               required minlength="6"
                               placeholder="Nhập mật khẩu">
                    </div>
                    <div class="form-group">
                        <label> Xác nhận mật khẩu</label>
                        <input type="password" class="form-control" id="conf_pass" name="conf_pass"
                               required minlength="6"
                               placeholder="Nhập mật khẩu">
                    </div>

                    <div class="clearfix"></div>
                    <br/>
                    <span id="indicator"></span>
                    <button type="submit" class="btn btn-success" id="submit_reg" name="submit_reg">Đăng ký</button>

                    <script>
                        $('#conf_pass').keyup(function () {
                            var pass = $('#reg_pass').val();
                            var cpass = $('#conf_pass').val();

                            if (pass.length < 6) {
                                $('#indicator').html('Mật khẩu quá ngắn, vui lòng thử lại!').css('color', 'red');
                                $('#submit_reg').attr({disabled: true});
                            } else if (pass != cpass) {
                                $('#indicator').html('Mật khẩu không giống nhau, vui lòng thử lại!').css('color', 'red');
                                $('#submit_reg').attr({disabled: true});
                            } else {
                                $('#indicator').html('Mật khẩu giống nhau, có thể đăng ký!').css('color', 'green');
                                $('#submit_reg').attr({disabled: false});
                            }
                        });
                    </script>
                </form>
            </div>
            <div class="modal-footer">

                <button type="button" class="btn btn-danger" data-dismiss="modal">Thoát</button>
            </div>
        </div>
    </div>
</div>

<style>
    .iconf {
        background: #313131;
        width: 40px;
        height: 40px;
        border-radius: 50%;
        text-align: center;
    / margin-left: 20 px;
    / margin-top: 10 px;
        margin-right: 10px;
    }

    .tenf {
        font-size: 15px;
        line-height: 16px;
        color: #fff;
    }

    @media only screen and (max-width: 1000px)  and (max-width: 680px)
    and (-webkit-min-device-pixel-ratio: 1) {
        .theloaif {

            display: none;
        }

        .tenf {

            text-align: center;

        }

    }
</style>

<!-- Footer -->
<!-- Footer -->
<footer class="page-footer font-small blue pt-4 footer2"
        style="background: #e0e0e0;padding-bottom: 20px;background: #161616f0;">

    <!-- Footer Links -->
    <div class="container">

        <!-- Grid row -->
        <div class="row" style="margin-top: 30px;">
            <div class="tenf" align="center">
                <p>Chủ sở hữu website: Công ty Cổ phần Công nghệ Truyền thông Xmedia</p>
                <p>Số Giấy chứng nhận kinh doanh: 0107829047</p>
                <p>Ngày cấp: 04/05/2017</p>
                <p>Nơi cấp: Phòng Đăng ký kinh doanh, Sở kế hoạch và đầu tư thành phố Hà Nội</p>
                <p>Tên người đại diện: Nguyễn Minh Dũng</p>
                <p>Giấy phép MXH: Website đang trong quá trình xin giấy cấp phép.</p>
            </div>
            <div class="clearfix"></div>

            <!--            <div class="col-sm-6 theloaif " style="padding-left: 30px;padding-top:3px;">-->
            <!--                <div class="row  footer4">-->
            <!--                    <ul>-->
            <!--                        <p style="color: #fff;font-weight: bold;font-size:17px;text-transform: uppercase">Xem thêm</p>-->
            <!---->
            <!--                    </ul>-->
            <!--                </div>-->
            <!--                <div class="row footer4">-->
            <!--                    <ul>-->
            <!--                        <li class="iconf"><i class="fa fa-facebook" aria-hidden="true"-->
            <!--                                             style="color: #FF9800;font-size: 16px; font-size: 20px; padding-top: 11px;"></i>-->
            <!--                        </li>-->
            <!--                        <li class="iconf"><i class="fa fa-google" aria-hidden="true"-->
            <!--                                             style="    color: #FF9800;font-size: 16px;font-size: 20px; padding-top: 11px;"></i>-->
            <!--                        </li>-->
            <!--                        <li class="iconf"><i class="fa fa-twitter" aria-hidden="true"-->
            <!--                                             style="    color: #FF9800;font-size: 16px; font-size: 20px; padding-top: 11px;"></i>-->
            <!--                        </li>-->
            <!--                        <li class="iconf"><i i class="fa fa-youtube-play" aria-hidden="true"-->
            <!--                                             style="    color: #FF9800;font-size: 16px; font-size: 20px; padding-top: 11px;"></i>-->
            <!--                        </li>-->
            <!---->
            <!---->
            <!--                    </ul>-->
            <!--                </div>-->
            <!---->
            <!---->
            <!--            </div>-->


        </div>
        <!-- Grid row -->

    </div>
    <!--    <div class="footer-copyright text-center py-3" style="background: black;">-->
    <!--        © 2018 Copyright:-->
    <!---->
    <!--    </div>-->


</footer>
<!-- Footer -->
<div id="fb-root"></div>

<script>(function (d, s, id) {
        var js, fjs = d.getElementsByTagName(s)[0];
        if (d.getElementById(id)) return;
        js = d.createElement(s);
        js.id = id;
        js.src = 'https://connect.facebook.net/vi_VN/sdk.js#xfbml=1&version=v3.2&appId=212346869200447&autoLogAppEvents=1';
        fjs.parentNode.insertBefore(js, fjs);
    }(document, 'script', 'facebook-jssdk'));</script>

<script>
    $('.owl-carousel').owlCarousel({
        loop: true,
        margin: 10,
        nav: true,
        navText: ["<img src='http://xemlien.vn/images/prev.png' width='30%'>", "<img src='http://xemlien.vn/images/next.png'  width='30%'>"],
        responsive: {
            0: {
                items: 2
            },
            600: {
                items: 3
            },
            1000: {
                items: 5
            }
        }
    })
</script>


<script type="text/javascript">jQuery(document).ready(function () {
        $(function () {
            var arr_src = [];
            arr_src[0] = 'http://mobiclip.vn/static//img.ads/0/0/0/9131_large.jpg';
            arr_src[1] = 'http://mobiclip.vn/static//img.ads/0/0/0/9128_large.jpg';
            arr_src[2] = 'http://mobiclip.vn/static//img.ads/0/0/0/9125_large.jpg';
            arr_src[3] = 'http://mobiclip.vn/static//img.ads/0/0/0/9119_large.jpg';
            arr_src[4] = 'http://mobiclip.vn/static//img.ads/0/0/0/9116_large.jpg';
            var count_page = 0;
            var swiper = new Swiper('.clip-banner.swiper-container', {
                pagination: '.swiper-pagination',
                prevButton: '.swiper-button-prev',
                nextButton: '.swiper-button-next',
                paginationClickable: true,
                paginationBulletRender: function (index) {
                    var image_page = '<span class="swiper-pagination-bullet"><img src="' + (arr_src[(count_page) % (arr_src.length)]) + '" /></span>';
                    count_page++;
                    return image_page;
                },
                slidesPerView: 'auto',
                loop: true,
                autoplay: 6000
            });
        });
        reload_slide_home();
        jQuery('#alert-modal').modal({"show": false});
    });</script>

<script type="text/javascript" src="<?= base_url(); ?>js/noen.js"></script>


<!-- Footer -->
</html>