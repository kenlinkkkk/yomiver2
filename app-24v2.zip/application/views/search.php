<?php
/**
 * Created by PhpStorm.
 * User: Truong Minh Duong
 * Date: 15/11/2018
 * Time: 10:15 SA
 */

?>

<div class="container" style="margin-top:30px">
    <div class="row" style="margin-top: -25px;">
        <div class="col-sm-12 nopadding">
            <div class="col-xs-12">
                <p class="tieude"><a href="<?= base_url(); ?>"><font color="red">Kết quả tìm kiếm</font></a></p>
                <!-- het test-->
                <div class="">
                    <?
                    if (empty($data_search->result())) {
                        echo "Không có dữ liệu, vui lòng kiểm tra lại!";
                    } else {
                        foreach ($data_search->result() as $row) { ?>
                            <div class="col-md-3">
                                <a href="<?= base_url() . 'video/' . $row->article_url; ?>" class="thumbnail"> <img
                                            src="<?= $row->images; ?>"
                                            alt="<?= $row->title; ?>"></a>
                                <div class="mota1">
                                    <p class="mota2" style="color: blue;    margin-right: 20px;"><a
                                                href="<?= base_url() . 'video/' . $row->article_url; ?>"><font
                                                    color="#1e90ff"><?= subTitle($row->title, 10); ?></font> </a></p>

                                </div>
                                <div class="clearfix"></div>
                                <div class="col-xs-12 nopadding" style="font-size: 12px;">
                                    <p style="line-height: 8px;color:orange; float: left"><?= ' ' . $row->views . ' lượt xem'; ?>
                                        &nbsp;&nbsp;
                                        <span
                                                class="glyphicon glyphicon-time"></span><?= ' ' . time2ago(strtotime($row->created_at)); ?>
                                    </p>
                                </div>
                            </div>
                        <? }
                    } ?>
                </div>
            </div>

        </div>
    </div>
</div>
