<div class="container" style="margin-top:30px">
    <div class="row" style="    margin-top: -25px;">
        <div class="col-sm-12 nopadding">
            <div class="col-sm-8 nopadding">
                <div class="xem panel panel-default">
                    <div class="panel-body">
                        <img src="<?= $images; ?>">
                    </div>
                </div>
                <div class="col-md-12">
                    <div class="row tdfb" style="background-color: #b8c7ce; border-radius: 5px;">
                        <div class="col-sm-12">
                            <p class="" style="padding: 10px 10px 0px 10px;"><font
                                        size="3"><strong><?= $title; ?></strong></font></p>
                        </div>
                        <div class="col-sm-12 tdxem">
                            <p class="" style="float: left; padding-left: 10px;"><font
                                        size="2"><?= 'Đăng bởi: ' . $username; ?></font></p>
                            <p class="" style="float: right; padding-right: 10px;"><font
                                        size="2"><?= time2ago(strtotime($created_at)); ?></font></p>
                        </div>
                        <div style="padding-left: 20px;">
                            <button type="button" class="btn btn-primary btn-xs btn-danger"><i class="fa fa-gift"
                                                                                               style="font-size:12px;color:#fff"></i>
                                Tặng quà
                            </button>
                            <button type="button" style="background-color: #4267b2" class="btn btn-primary btn-xs"><i
                                        class="fa fa-eye" aria-hidden="true"></i> <?= $views . ' lượt xem'; ?>
                            </button>
                            <div class="fb-like" data-layout="button" data-href="<?= base_url() . 'anh/' . $link; ?>"
                                 data-action="like" data-size="large" data-show-faces="true" data-share="true"></div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-12">
                            <div class="binhluan2">
                                <div class="row">
                                    <div class="col-xs-12 panel panel-default nopadding">
                                        <div class="panel-body">
                                            <div>
                                                <form action="" method="post">
                                                    <div class="col-xs-8 nopadding">
                                                <textarea class="form-control" id="comment" name="comment"
                                                          style="height: 50px"
                                                          placeholder="Mời bạn nhập bình luận" required></textarea>
                                                    </div>
                                                    <div class="col-xs-4" style="float: right;">
                                                        <button type="submit" class="btn btn-success" name="submitcmt">
                                                            Bình luận
                                                        </button>
                                                    </div>
                                                </form>
                                            </div>
                                            <div class="clearfix"></div>
                                            <? foreach ($data_list_comment->result() as $row) { ?>
                                                <div style="padding-top: 5px;">
                                                    <div class="col-sm-2">
                                                        <img src="<?= $row->avatar; ?>" width="50px" height="50px">
                                                    </div>
                                                    <div class="col-sm-10" style="line-height: 10px;">
                                                        <p><font color="#1e90ff">
                                                                <b><?= $row->username; ?></b>
                                                            </font></p>
                                                        <p><?= $row->comment; ?></p>
                                                        <p><i><font size="2">
                                                                    <?= time2ago(strtotime($row->cmt_date)); ?>
                                                                </font> </i></p>
                                                    </div>
                                                </div>
                                            <? } ?>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-sm-4">
                <div class="qc">
                    <img src="<?= base_url(); ?>images/qc.png">
                </div>
                <div class="videolienquan">
                    <div class="row" style="margin-top: 10px">
                        <div class="col-md-12 nopadding">
                            <p style="font-size: 15px; background-color: #8aa4af; height: 30px;"><b
                                        style="padding: 10px;">TIN LIÊN QUAN</b></p>
                        </div>
                    </div>
                    <? foreach ($data_list_article_cate->result() as $row) { ?>
                        <div class="row col-md-12 col-xs-6 nopadding" style="margin-top: 10px;">

                            <div class="col-md-6 col-xs-12 nopadding">
                                <div class="videolq"><p><a href="<?= base_url() . 'anh/' . $row->article_url; ?>"><img
                                                    src="<?= $row->images; ?>"></a></p></div>
                            </div>
                            <div class="col-md-6 col-xs-12 nopadding">
                                <div class="tenlq" style="padding-left: 10px;">
                                    <p class="chu5"><a href="<?= base_url() . 'anh/' . $row->article_url; ?>"><font
                                                    color="#1e90ff" size="3"><?= $row->title; ?></font> </a></p>

                                    <p class="chu6"><? echo 'Đăng bởi: ';
                                        if (empty($row->art_username)) echo $row->username;
                                        echo $row->art_username;
                                        '</b>'; ?></p>
                                    <div class=" row">
                                        <div class="col-sm-6">
                                            <p class="chu6"><?= $row->views . ' lượt xem'; ?></p>
                                        </div>
                                        <div class="col-sm-6">
                                            <p class="chu7"><?= time2ago(strtotime($row->created_at)); ?></p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    <? } ?>
                </div>
            </div>
        </div>
    </div>
</div>