// JavaScript Document
<!--
function SelectInCombobox(obj,val){
	//var obj=document.Items.CountryName;
	//var val = "{iCountryID}";
	//alert(val);
	for(i=0;i<obj.length;i++)
		{
			if(obj[i].value == val)
				{
				   obj[i].selected = "selected"; 
				   break;
			   }
		}
	}
function contain_invalid(str,invalidstr){
		for(i=0;i<str.length;i++){
			if(invalidstr.indexOf(str.charAt(i))>=0) return false;			
		}
		return true;
	}

//var on_off_HIM = 1; //On H.I.M
function limitLen(t,l){
	var mlength=t.getAttribute? parseInt(t.getAttribute("maxlength")):"";
	tmp=trim(t.value);
	if(tmp.length > mlength) {
		//alert('vuot qua');
		t.value=tmp.substr(0,mlength)
		t.focus();
	}
	l.value=mlength-t.value.length;
	//alert(mlength-t.value.length);
}

function set(What,Value) {
    if (document.layers && document.layers[What] != null) document.layers[What].visibility = Value;
    else if (document.all) eval('document.all.'+What+'.style.visibility ="'+ Value+'"');
	else if (document.getElementById) document.getElementById(What).style.visibility = Value;
}

function showhide(id,state){
	document.getElementById(id).style.display = state; 
}


function hideAllSubmenu()
{	document.all("orderform",0).style.display = "none";
}
function showform(id)
{		

	if (document.getElementById(id).style.display == "none")
	{ 
		document.getElementById(id).style.display = ""; 
	}
	else 
	{ 
		document.getElementById(id).style.display = "none";
	}
}

function Open(url, name, property)
{
	newwindow=window.open(url, name, property);
	if (window.focus) {
		newwindow.focus()
	}
	return false;
}
function OpenWindow(url, name, width, height, property)
{
	var x = (screen.width - width) / 2;
	var y = (screen.height - height - 60) / 2;
	property = 'top=' + y + ',left=' + x + ',width=' + width + 'px,height=' + height + 'px,' + property;
	newwindow=window.open(url, name, property);
	/*if (window.focus) {
		newwindow.focus()
	}*/
	return false;
}
function maxLength(oText, len) {
	if (oText.value.length>len) oText.value = oText.value.substr(0,len);
}
function numofchars(t,display){
	display.value=trim(t.value).length
}
function ismaxlength(obj) {
	var mlength=obj.getAttribute? parseInt(obj.getAttribute("maxlength")) : ""
	if (obj.getAttribute && obj.value.length>mlength)
	obj.value=obj.value.substring(0,mlength-1)
}

function isInteger(s) {   
	var i;
    for (i = 0; i < s.length; i++) {   
        // Check that current character is number.
        var c = s.charAt(i);
        if (((c < "0") || (c > "9"))) return false;
    }
    // All characters are numbers.
    return true;
}
function checkNormalChar(stringIn) {
	 retval = false 
	 var i;
     for (i=0;i<=stringIn.length-1;i++) { 
     	 //cho phep nhung ky tu tu A->Z, a->z, 0->9,va cac ky tu @,_
	      if (((stringIn.charCodeAt(i) >= 48)&&(stringIn.charCodeAt(i) <= 57)) || ((stringIn.charCodeAt(i) >= 64)&&(stringIn.charCodeAt(i) <= 90)) || ((stringIn.charCodeAt(i) >= 97)&&(stringIn.charCodeAt(i) <= 122)) ||(stringIn.charCodeAt(i)==95) ||(stringIn.charCodeAt(i)==46) ||(stringIn.charCodeAt(i)==45)) { 
                retval = true;
      	  }else{
      	  		retval = false;
      	  		break;
         }
     }
	 return retval;
}
function checkInvalidName(stringIn) {
	if ((stringIn.indexOf("@") >= 0)||(stringIn.indexOf("<") >= 0)||(stringIn.indexOf(">") >= 0)||(stringIn.indexOf("!") >= 0)||(stringIn.indexOf("$") >= 0)||(stringIn.indexOf("%") >= 0)||(stringIn.indexOf("=") >= 0)||(stringIn.indexOf("#") >= 0)||(stringIn.indexOf("{") >= 0)||(stringIn.indexOf("}") >= 0)||(stringIn.indexOf("[") >= 0)||(stringIn.indexOf("]") >= 0)||(stringIn.indexOf("'") >= 0)||(stringIn.indexOf('"') >= 0))
	{
		return false;
	}
	return true;
}

function checkNormalName(stringIn) {
	if ((stringIn.indexOf("@") >= 0)||(stringIn.indexOf("<") >= 0)||(stringIn.indexOf(">") >= 0)||(stringIn.indexOf("!") >= 0)||(stringIn.indexOf("$") >= 0)||(stringIn.indexOf("%") >= 0)||(stringIn.indexOf("(") >= 0)||(stringIn.indexOf(")") >= 0)||(stringIn.indexOf("=") >= 0)||(stringIn.indexOf("#") >= 0)||(stringIn.indexOf("{") >= 0)||(stringIn.indexOf("}") >= 0)||(stringIn.indexOf("[") >= 0)||(stringIn.indexOf("]") >= 0)||(stringIn.indexOf("'") >= 0)||(stringIn.indexOf('"') >= 0))
	{
		return false;
	}
	return true;
}

function checkUsername(stringIn) {
	retval = false 
	for (var i=0;i<=stringIn.length-1;i++) { 
	//Kiem tra nhung ky tu tren ban phim va khac ky 2 tu ',"
	//&&(stringIn.charCodeAt(i) != 39)&&(stringIn.charCodeAt(i) != 34)&&(stringIn.charAt(i) != ' ')
		if  ((stringIn.charCodeAt(i) != 39)&&(stringIn.charCodeAt(i) != 34)) { 
		   retval = true;
		}else{
	  		retval = false;
	  		break;
		}
	}
	return retval;
}

/*function checkUsernameRegis(stringIn) {
	if ((stringIn.indexOf("<") >= 0)||(stringIn.indexOf(">") >= 0)||(stringIn.indexOf("!") >= 0)||(stringIn.indexOf("$") >= 0)||(stringIn.indexOf("%") >= 0)||(stringIn.indexOf("(") >= 0)||(stringIn.indexOf(")") >= 0)||(stringIn.indexOf("=") >= 0)||(stringIn.indexOf("#") >= 0)||(stringIn.indexOf("{") >= 0)||(stringIn.indexOf("}") >= 0)||(stringIn.indexOf("[") >= 0)||(stringIn.indexOf("]") >= 0)||(stringIn.indexOf("'") >= 0)||(stringIn.indexOf('"') >= 0)||(stringIn.indexOf('@') >= 0)||(stringIn.indexOf('.') >= 0)||(stringIn.indexOf(' ') >= 0)||(stringIn.indexOf('&') >= 0)||(stringIn.indexOf(':') >= 0)||(stringIn.indexOf(',') >= 0)||(stringIn.indexOf('/') >= 0)||(stringIn.indexOf('\\') >= 0)||(stringIn.indexOf('*') >= 0)||(stringIn.indexOf('+') >= 0)||(stringIn.indexOf('|') >= 0)||(stringIn.indexOf('?') >= 0)||(stringIn.indexOf('~') >= 0)||(stringIn.indexOf('`') >= 0)||(stringIn.indexOf(';') >= 0))
	{
		return false;
	}
	return true;
}*/
function checkUsernameRegis(username) {
	var re=/^[a-zA-Z0-9_\-]+$/;
	if(username.match(re) == null)
	{
		return false;
	}
	return true;
}

function checkFirstName(stringIn) {
	if ((stringIn.indexOf("@") >= 0)||(stringIn.indexOf("<") >= 0)||(stringIn.indexOf(">") >= 0)||(stringIn.indexOf("!") >= 0)||(stringIn.indexOf("$") >= 0)||(stringIn.indexOf("%") >= 0)||(stringIn.indexOf("(") >= 0)||(stringIn.indexOf(")") >= 0)||(stringIn.indexOf("=") >= 0)||(stringIn.indexOf("#") >= 0)||(stringIn.indexOf("{") >= 0)||(stringIn.indexOf("}") >= 0)||(stringIn.indexOf("[") >= 0)||(stringIn.indexOf("]") >= 0)||(stringIn.indexOf("'") >= 0)||(stringIn.indexOf('"') >= 0)||(stringIn.indexOf(' ') >= 0))
	{
		return false;
	}
	return true;
}
function valid_chars(str,special_str){
	if(special_str=='') special_str='@#%^*~<>';  
	for(i=0;i<str.length;i++){
		if(special_str.indexOf(str.charAt(i))>=0)
			return false;
	}
	return true;
}
function checkEmail(mail){
	mail = trim(mail);
	var re=/^[\w-]+(\.[\w-]+)*@([\w-]+\.)+[a-zA-Z]{2,4}$/
	if(mail.match(re) == null)
		return false;
	return true;
}
/*
function checkEmail1(str) {
  var re=/^[\w-]+(\.[\w-]+)*@([\w-]+\.)+[a-zA-Z]{2,4}$/
  if (str.match(re)) {
  	if(str.indexOf('@')>32)
		return false;
	return true;
  }
}*/
function checkWebsite(str) {
  var re=/^[\w-]+([\w-]+\.)+[a-zA-Z]{2,4}$/
  var re1=/^http:\/\/[\w-]+([\w-]+\.)+[a-zA-Z]{2,4}$/
  
  if (str.match(re)) {
  	return true
  } 
  else if (str.match(re1)) {
  	return true
  } 
  else return false;
}
function stripCharsInBag(s, bag)
{   var i;
    var returnString = "";
    // Search through string's characters one by one.
    // If character is not in bag, append to returnString.
    for (i = 0; i < s.length; i++)
    {   
        // Check that current character isn't whitespace.
        var c = s.charAt(i);
        if (bag.indexOf(c) == -1) returnString += c;
    }
    return returnString;
}

function checkPhone(stringIn) {
	var i;	
	if ((stringIn.length<6) || (stringIn.length>30)){
		return false;
	}
	var validWorldPhoneChars="()-+ ";
	s=stripCharsInBag(stringIn,validWorldPhoneChars);
    for (i = 0; i < s.length; i++)
    {   
        // Check that current character is number.
        var c = s.charAt(i);
        if (((c < "0") || (c > "9"))) return false;
    }
    // All characters are numbers.
    return true;
}

function checkMobile(stringIn) {
	var i;
	if ((stringIn.length<6) || (stringIn.length>20)){
		return false;
		}
    for (i = 0; i < stringIn.length; i++)
    {   
        // Check that current character is number.
        var c = stringIn.charAt(i);
        if (((c < "0") || (c > "9"))) return false;
    }
    // All characters are numbers.
    return true;
}

function checkPassword(stringIn) {
	retval = false 
	for (var i=0;i<=stringIn.length-1;i++) { 
	//Kiem tra nhung ky tu tren ban phim va khac ky 2 tu ',"
	//&&(stringIn.charCodeAt(i) != 39)&&(stringIn.charCodeAt(i) != 34)&&(stringIn.charAt(i) != ' ')
		if  ( (stringIn.charCodeAt(i) >= 32)&&(stringIn.charCodeAt(i) <= 126) ) { 
		   retval = true;
		}else{
	  		retval = false;
	  		break;
		}
	}
	return retval;
}

function checkPasswordRegis(stringIn) {
	retval = false 
	for (var i=0;i<=stringIn.length-1;i++) { 
	//Kiem tra nhung ky tu tren ban phim va khac ky 2 tu ',"
	//&&(stringIn.charCodeAt(i) != 39)&&(stringIn.charCodeAt(i) != 34)&&(stringIn.charAt(i) != ' ')
		if  ( (stringIn.charCodeAt(i) >= 32)&&(stringIn.charCodeAt(i) <= 126)&&(stringIn.charCodeAt(i) != 39)&&(stringIn.charCodeAt(i) != 34)&&(stringIn.charAt(i) != ' ')) { 
		   retval = true;
		}else{
	  		retval = false;
	  		break;
		}
	}
	return retval;
}
/*
function RefreshCity()
{	
	var f = document.editFrm;		
	var listCountry = f.jobseek_country;
	var listCity = f.jobseek_city;	
	var countryID = listCountry.options[listCountry.selectedIndex].value;	
	var arrChildren;
	var arrTemp	;
	var i;
	var x = 0;
	
	listCity.length = 0 ;				
	var strChildCityList = f.city.value;
	arrChildren = strChildCityList.split("|")	
	
	for (i = 0; i< arrChildren.length; i++)
	{
		arrTemp = arrChildren[i].split("~");
		if (countryID == parseInt(arrTemp[0])) 
		{
			listCity.options[x] = new Option(arrTemp[2], arrTemp[1]);
			x++
		}
		
	}
}
*/
function checkvaliddate(){
	var form = document.editFrm;		
	
	if ((form.dbirth.value!="00") && (form.mbirth.value!="00") && (form.ybirth.value!="0000")){	
		mb=form.mbirth.value;
		if (form.mbirth.value<10){
			mb="0"+form.mbirth.value;
		}	
		
		dbir=form.dbirth.value;
		if (form.dbirth.value<10){
			dbir="0"+form.dbirth.value;
		}		
		//alert(dbir);
		dtStr=mb+"-"+dbir+"-"+form.ybirth.value;
		
		if (isDate(dtStr)){
			return true;
		}
		else{
			return false
		}
	}
	else{
		if ((form.dbirth.value=="00") && (form.mbirth.value=="00") && (form.ybirth.value=="0000")){
			return false;
		}				
	}
	return false;
	
}

function SetChecked(val, chkName, fname) {
	var dml=document.forms[fname];
	var len = dml.elements.length;
	var i=0;
	for( i=0 ; i<len ; i++) {
		if (dml.elements[i].name==chkName) {
			dml.elements[i].checked=val;
		}
	}
}

function checkChecked(chkName, fname) {
	var dml=document.forms[fname];
	var len = dml.elements.length;
	var i=0, count=0;
	for( i=0 ; i<len ; i++) {
		if (dml.elements[i].name==chkName) {
			if(dml.elements[i].checked)
				count++;
		}
	}
	if(count>0)
		return true;
	return false;
}

function nonBlankValue(stringIn) {
	   var numn = stringIn.length;
	   for(i=0;i<stringIn.length;i++) {
			 if(stringIn.charAt(i)==" ") 
				 numn -=1;
	   }
	   return (numn);
}
function trim(sString) {
	while (sString.substring(0,1) == ' ') {
		sString = sString.substring(1, sString.length);
	}
	while (sString.substring(sString.length-1, sString.length) == ' ') {
		sString = sString.substring(0,sString.length-1);
	}
	return sString;
}

function checkDate(day, month, year)
{
	if ((month==4 || month==6 || month==9 || month==11) && day==31)
		return false

	if (month == 2) { // check for february 29th
		var isleap = (year % 4 == 0 && (year % 100 != 0 || year % 400 == 0));
		if (day>29 || (day==29 && !isleap))
			return false;
	}
	return true;
}

// -->