// làm nút quay lên top
(function($){
	var offset=300,//biến chiều cao khi kéo xuống sẽ hiện nút
	scroll_opacity=1200,//khỏang thời gian nút sẽ mờ đi
	scroll_duration=700;//khoảng thời gian kéo lên top
	$back_to_top=$('.back-to-top');//Gán DOM vào biến là class bên HTML
	//thêm class để nút hiện lên
	$(window).scroll(function(){
		 ( $(this).scrollTop()>offset)? $back_to_top.addClass('visible'):$back_to_top.removeClass('visible fade-out');
		 if($(this).scrollTop() > scroll_opacity){
			 $back_to_top.addClass('fade-out');
		 }
		 
	});
	
	$back_to_top.on('click',function(event){
		window.event.preventDefaulf();
		$('html,body').animate({scrolltop:0},scroll_duration);
	});
	
})(jQuery);

(function($){
	$('.btn-login').click(function(){
		$('.login').addClass('login-hienra');
		});
})(jQuery);
// làm nút quay lên top
