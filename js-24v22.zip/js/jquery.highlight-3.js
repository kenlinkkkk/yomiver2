/*

highlight v3

Highlights arbitrary terms.
*/
(function($) {
	$.fn.highlight = function(words, options) {
		var defaults = {
			backcolor: '#FFFF99',
			forecolor: 'black'
		};
		
		var options = $.extend(defaults, options);
		
		if(typeof words == 'string') {
			words = [ words ];
		}
		
		return this.each(function() {
			for(var i=0;i<words.length;i++) {
				var span = '<span style="background:' + 
					options.backcolor + ';color:' + 
					options.forecolor + '">' + words[i] + '</span>';
				this.innerHTML = this.innerHTML
					.replace(new RegExp(words[i], 'gi'), span);
			}
		});
	};
})(jQuery);
