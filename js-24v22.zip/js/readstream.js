
	  var readstream_enabled = 1;
	  var readstream_target = '.readstream';
	  var readstream_display = 0;
	  var readstream_read = [];


 
$(window).bind('scroll', function() {
if ($('.readstream').length >0 ){ // check object exist;
  if (!readstream_enabled) {
    return;
  }
  var x = $(readstream_target);
  var distance_from_bottom = x.offset().top + x.innerHeight() - window.innerHeight - window.scrollY;
  if (distance_from_bottom < 0) {
   readstream_show();
  }
  else if (distance_from_bottom > 0) {
	readstream_hide();
  }}
});



 function readstream_show() {
  if (readstream_display) {
    return;
  }
 //_gaq.push(['_trackEvent', 'Interactive', 'Readstream display'], ['_trackPageview']);
  readstream_display = 1;
  readstream_random();
};

 function readstream_hide()  {
  if (!readstream_display) {
    return;
  }
  readstream_display = 0;
  $('#readstream').slideToggle();
};

function readstream_close() {
   $('#readstream').hide();
  readstream_enabled = 0;
}

// Fetch data if necessary, then show a random article.
 function  readstream_random (data) {
	
  if (!data) {
    $('body').append('<div id="readstream"><div class="close">x</div><div class="readstream-title">Có thể bạn quan tâm:</div><div class="content"></div></div>');
    $('#readstream .close').click(function() {
      readstream_close();
    });
	
    $.getJSON('readstream.php', function(data) {
      readstream_data = data;
      readstream_random(data);
    });
    return;
  }
 
  // Get a list of all suggested nids, excluding read nodes.
  var nids = [];
  for (var nid in data) {
    if (readstream_read.indexOf(':' + nid + ':') === -1) {
      nids.push(nid);
    }
  }
   
  // If all nodes are read, get a list of all nodes.
  if (!nids.length) {
    for (var nid in data) {
      nids.push(nid);
    }
  }
  
  // Then get a random nid from that list
  var nid = Math.floor(Math.random() * nids.length);
  $('#readstream .content').html(data[nids[nid]]);
  $('#readstream').slideToggle('slow');
}

 


//Drupal.readstream = {'target': '.content', 'display': 0, 'enabled': 1, 'read': []};
/* 
 function readstream(context) {
  if (context !== document || !localStorage) {
    return;
  }

  // Adds current nid to the read list. Remove old nids if necessary.
  var read = localStorage.getItem('readstream');
  if (!read) {
    read = ':';
  }
  read = read.replace(':' + readstream.nid + ':', ':');
  read += readstream.nid + ':';
  
  // Trim it for better performance
  if (read.length > 20000) {
    read = read.substr(-20000);
  }
  readstream_read = read;
  localStorage.setItem('readstream', read);
}
*/